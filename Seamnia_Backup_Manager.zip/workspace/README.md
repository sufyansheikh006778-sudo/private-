# Seamnia Backup Manager

Centralized portal for Seamnia Software House clients to upload weekly SQL Server `.BAK` files, and for administrators to review, verify, download and manage those backups.

This application is **manual upload only**. It does not connect to client SQL Servers or run an automatic backup agent.

## Stack

- Backend: ASP.NET Core 8, C#, Entity Framework Core, JWT
- Frontend: React, Vite, TypeScript, Tailwind CSS
- Database: Microsoft SQL Server (production). SQLite is used automatically for local preview when SQL Server is not available.
- Storage: filesystem folders under `SeamniaBackupStorage/Client_XXX/`
- Integrity: SHA-256

## Default accounts (change after first login)

| Role | Username | Password |
| --- | --- | --- |
| Super Admin | `superadmin` | `Seamnia@Admin2026!` |
| Admin | `admin` | `Seamnia@Admin2026!` |
| Demo Client | `demo.client` | `Client@2026!` |

## Weekly quota

- One successful upload per client per Monday–Sunday week, Pakistan Standard Time.
- Failed, cancelled and incomplete uploads do not consume the quota.
- Administrators can grant extra credits. Every override is written to Audit Logs.

## Local development

```bash
# Backend (http://localhost:5080)
cd backend/Seamnia.BackupManager.Api
dotnet run

# Frontend (http://localhost:5173, proxies /api to the backend)
cd frontend
npm install
npm run dev
```

## Production (Windows Server + IIS + SQL Server)

1. Create the database using `database/schema.sql`.
2. Set `Database:Provider` to `SqlServer` and update `ConnectionStrings:SqlServer` in `appsettings.json`.
3. Set a unique `Jwt:Key` (32+ characters).
4. Set `Storage:RootPath` to a dedicated volume, for example `D:\SeamniaBackupStorage`.
5. Optionally set `Verification:SqlServerConnection` to an **isolated** SQL Server instance used only for `RESTORE VERIFYONLY`. Never point this at production databases.
6. Publish the API:

```bash
dotnet publish backend/Seamnia.BackupManager.Api -c Release -o C:\inetpub\SeamniaBackupManager
```

7. Build the frontend and copy `frontend/dist` into the IIS site, or host the SPA behind the same site with `/api` forwarded to Kestrel/IIS.

```bash
cd frontend
npm run build
```

8. Bind the IIS site to HTTPS. Increase `maxAllowedContentLength` (see `web.config`) so 100 MB chunks are accepted.

## Security notes

- Client identity and storage folders are taken from the JWT, never from the request body.
- Only `.BAK` files are accepted. Files are stored on disk, not in SQL Server.
- Downloads require authentication. Incomplete or corrupted uploads never become successful backups.
- Isolated verification uses SHA-256 plus optional `RESTORE VERIFYONLY` against a dedicated SQL instance.

## Project layout

```text
backend/Seamnia.BackupManager.Api   ASP.NET Core API
frontend                             React portal
database/schema.sql                  SQL Server schema
SeamniaBackupStorage                 Runtime file store (created on first run)
```
