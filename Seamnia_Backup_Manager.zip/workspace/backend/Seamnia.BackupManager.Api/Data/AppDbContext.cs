using Microsoft.EntityFrameworkCore;
using Seamnia.BackupManager.Api.Models;

namespace Seamnia.BackupManager.Api.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<User> Users => Set<User>();
    public DbSet<Client> Clients => Set<Client>();
    public DbSet<Backup> Backups => Set<Backup>();
    public DbSet<UploadSession> UploadSessions => Set<UploadSession>();
    public DbSet<UploadChunk> UploadChunks => Set<UploadChunk>();
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();
    public DbSet<SystemSetting> SystemSettings => Set<SystemSetting>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<User>(e =>
        {
            e.HasIndex(x => x.Username).IsUnique();
            e.Property(x => x.Username).HasMaxLength(80).IsRequired();
            e.Property(x => x.FullName).HasMaxLength(160);
            e.Property(x => x.Email).HasMaxLength(160);
            e.Property(x => x.Role).HasMaxLength(32).IsRequired();
            e.HasOne(x => x.Client).WithMany(c => c.Users).HasForeignKey(x => x.ClientId).OnDelete(DeleteBehavior.SetNull);
        });

        modelBuilder.Entity<Client>(e =>
        {
            e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Code).HasMaxLength(32).IsRequired();
            e.Property(x => x.CompanyName).HasMaxLength(200).IsRequired();
            e.Property(x => x.StorageFolder).HasMaxLength(80).IsRequired();
        });

        modelBuilder.Entity<Backup>(e =>
        {
            e.HasIndex(x => x.Sha256Hash);
            e.HasIndex(x => new { x.ClientId, x.CreatedAt });
            e.Property(x => x.OriginalFileName).HasMaxLength(260).IsRequired();
            e.Property(x => x.UploadStatus).HasMaxLength(32);
            e.Property(x => x.VerificationStatus).HasMaxLength(64);
            e.HasOne(x => x.Client).WithMany(c => c.Backups).HasForeignKey(x => x.ClientId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.UploadedByUser).WithMany().HasForeignKey(x => x.UploadedByUserId).OnDelete(DeleteBehavior.SetNull);
        });

        modelBuilder.Entity<UploadSession>(e =>
        {
            e.HasIndex(x => new { x.ClientId, x.Status });
            e.HasOne(x => x.Client).WithMany().HasForeignKey(x => x.ClientId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.User).WithMany().HasForeignKey(x => x.UserId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<UploadChunk>(e =>
        {
            e.HasIndex(x => new { x.UploadSessionId, x.ChunkIndex }).IsUnique();
            e.HasOne(x => x.UploadSession).WithMany(s => s.Chunks).HasForeignKey(x => x.UploadSessionId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<AuditLog>(e =>
        {
            e.HasIndex(x => x.CreatedAt);
            e.Property(x => x.Action).HasMaxLength(80);
            e.Property(x => x.EntityType).HasMaxLength(80);
        });

        modelBuilder.Entity<SystemSetting>(e =>
        {
            e.HasIndex(x => x.Key).IsUnique();
            e.Property(x => x.Key).HasMaxLength(80).IsRequired();
        });
    }
}
