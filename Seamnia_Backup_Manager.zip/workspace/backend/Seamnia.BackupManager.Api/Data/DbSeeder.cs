using Microsoft.EntityFrameworkCore;
using Seamnia.BackupManager.Api.Models;
using Seamnia.BackupManager.Api.Services;

namespace Seamnia.BackupManager.Api.Data;

public static class DbSeeder
{
    public static async Task SeedAsync(AppDbContext db, StorageService storage)
    {
        await db.Database.EnsureCreatedAsync();

        if (!await db.SystemSettings.AnyAsync())
        {
            var now = PktTime.Now;
            db.SystemSettings.AddRange(
                new SystemSetting { Key = "MaxFileSizeBytes", Value = "53687091200", Description = "Maximum backup file size (50 GB)", UpdatedAt = now },
                new SystemSetting { Key = "ChunkSizeBytes", Value = "104857600", Description = "Upload chunk size (100 MB)", UpdatedAt = now },
                new SystemSetting { Key = "TotalStorageBytes", Value = "21990232555520", Description = "Total allocated storage (20 TB)", UpdatedAt = now },
                new SystemSetting { Key = "SessionExpiryHours", Value = "72", Description = "Incomplete upload session expiry", UpdatedAt = now },
                new SystemSetting { Key = "CompanyName", Value = "Seamnia Software House", Description = "Organization name", UpdatedAt = now }
            );
        }

        if (!await db.Users.AnyAsync())
        {
            var now = PktTime.Now;
            var demoClient = new Client
            {
                Code = "Client_001",
                CompanyName = "Demo Trading Co.",
                ContactName = "Ahmed Khan",
                ContactEmail = "ahmed@demotrading.local",
                ContactPhone = "+92-300-0000000",
                StorageFolder = "Client_001",
                IsActive = true,
                CreatedAt = now
            };
            db.Clients.Add(demoClient);
            await db.SaveChangesAsync();
            storage.EnsureClientFolder(demoClient.StorageFolder);

            db.Users.AddRange(
                new User
                {
                    Username = "superadmin",
                    PasswordHash = BCrypt.Net.BCrypt.HashPassword("Seamnia@Admin2026!"),
                    FullName = "Seamnia Super Administrator",
                    Email = "superadmin@seamnia.local",
                    Role = UserRoles.SuperAdmin,
                    IsActive = true,
                    CreatedAt = now
                },
                new User
                {
                    Username = "admin",
                    PasswordHash = BCrypt.Net.BCrypt.HashPassword("Seamnia@Admin2026!"),
                    FullName = "Seamnia Administrator",
                    Email = "admin@seamnia.local",
                    Role = UserRoles.Admin,
                    IsActive = true,
                    CreatedAt = now
                },
                new User
                {
                    Username = "demo.client",
                    PasswordHash = BCrypt.Net.BCrypt.HashPassword("Client@2026!"),
                    FullName = "Ahmed Khan",
                    Email = "ahmed@demotrading.local",
                    Role = UserRoles.Client,
                    IsActive = true,
                    ClientId = demoClient.Id,
                    CreatedAt = now
                }
            );
        }

        await db.SaveChangesAsync();
    }
}
