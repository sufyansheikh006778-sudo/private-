using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Seamnia.BackupManager.Api.Data;
using Seamnia.BackupManager.Api.Models;
using Seamnia.BackupManager.Api.Services;

namespace Seamnia.BackupManager.Api.Controllers;

[ApiController]
[Route("api/users")]
[Authorize(Roles = UserRoles.SuperAdmin)]
public class UsersController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly AuditService _audit;

    public UsersController(AppDbContext db, AuditService audit)
    {
        _db = db;
        _audit = audit;
    }

    [HttpGet]
    public async Task<ActionResult<List<UserDto>>> List([FromQuery] string? role)
    {
        var q = _db.Users.Include(u => u.Client).AsQueryable();
        if (!string.IsNullOrWhiteSpace(role))
            q = q.Where(u => u.Role == role);
        var users = await q.OrderBy(u => u.Role).ThenBy(u => u.Username).ToListAsync();
        return Ok(users.Select(Map).ToList());
    }

    [HttpPost]
    public async Task<ActionResult<UserDto>> Create([FromBody] CreateAdminRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.Username) || string.IsNullOrWhiteSpace(req.Password))
            return BadRequest(new { message = "Username and password are required." });
        if (await _db.Users.AnyAsync(u => u.Username == req.Username.Trim()))
            return Conflict(new { message = "Username already exists." });

        var user = new User
        {
            Username = req.Username.Trim(),
            PasswordHash = BCrypt.Net.BCrypt.HashPassword(req.Password),
            FullName = req.FullName?.Trim() ?? "",
            Email = req.Email?.Trim() ?? "",
            Role = UserRoles.Admin,
            IsActive = true,
            CreatedAt = PktTime.Now,
            MustChangePassword = true
        };
        _db.Users.Add(user);
        await _db.SaveChangesAsync();
        await _audit.LogAsync(CurrentUserId(), User.Identity?.Name ?? "", UserRoles.SuperAdmin, "CreateAdmin", "User", user.Id.ToString(), $"Created admin {user.Username}");
        return Ok(Map(user));
    }

    [HttpPut("{id:int}")]
    public async Task<ActionResult<UserDto>> Update(int id, [FromBody] UpdateUserRequest req)
    {
        var user = await _db.Users.Include(u => u.Client).FirstOrDefaultAsync(u => u.Id == id);
        if (user == null) return NotFound();
        if (user.Role == UserRoles.SuperAdmin && req.IsActive == false)
            return BadRequest(new { message = "Cannot deactivate the Super Admin." });

        if (req.FullName != null) user.FullName = req.FullName.Trim();
        if (req.Email != null) user.Email = req.Email.Trim();
        if (req.IsActive.HasValue) user.IsActive = req.IsActive.Value;
        if (!string.IsNullOrWhiteSpace(req.Password))
        {
            user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(req.Password);
            user.MustChangePassword = true;
        }
        await _db.SaveChangesAsync();
        await _audit.LogAsync(CurrentUserId(), User.Identity?.Name ?? "", UserRoles.SuperAdmin, "UpdateUser", "User", id.ToString(), $"Updated user {user.Username}");
        return Ok(Map(user));
    }

    private int CurrentUserId() => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    private static UserDto Map(User u) => new()
    {
        Id = u.Id,
        Username = u.Username,
        FullName = u.FullName,
        Email = u.Email,
        Role = u.Role,
        IsActive = u.IsActive,
        ClientId = u.ClientId,
        CompanyName = u.Client?.CompanyName,
        CreatedAt = u.CreatedAt,
        LastLoginAt = u.LastLoginAt
    };
}
