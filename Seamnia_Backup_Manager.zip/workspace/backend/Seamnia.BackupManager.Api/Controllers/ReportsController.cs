using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Seamnia.BackupManager.Api.Data;
using Seamnia.BackupManager.Api.Models;
using Seamnia.BackupManager.Api.Services;

namespace Seamnia.BackupManager.Api.Controllers;

[ApiController]
[Route("api/reports")]
[Authorize(Roles = $"{UserRoles.SuperAdmin},{UserRoles.Admin}")]
public class ReportsController : ControllerBase
{
    private readonly AppDbContext _db;

    public ReportsController(AppDbContext db)
    {
        _db = db;
    }

    [HttpGet]
    public async Task<ActionResult<ReportDto>> Get()
    {
        var used = await _db.Backups.Where(b => b.UploadStatus == BackupStatuses.Success).SumAsync(b => (long?)b.FileSizeBytes) ?? 0;
        var top = await _db.Clients.Select(c => new ClientStorageRow
        {
            CompanyName = c.CompanyName,
            Code = c.Code,
            BackupCount = c.Backups.Count(b => b.UploadStatus == BackupStatuses.Success),
            StorageUsedBytes = c.Backups.Where(b => b.UploadStatus == BackupStatuses.Success).Sum(b => (long?)b.FileSizeBytes) ?? 0
        }).OrderByDescending(c => c.StorageUsedBytes).Take(10).ToListAsync();

        var since = PktTime.Now.AddDays(-56);
        var successes = await _db.Backups
            .Where(b => b.UploadStatus == BackupStatuses.Success && b.CompletedAt != null && b.CompletedAt >= since)
            .Select(b => b.CompletedAt!.Value)
            .ToListAsync();

        var weeks = new List<WeeklyCount>();
        var cursor = PktTime.CurrentWeek().Start.AddDays(-49);
        for (var i = 0; i < 8; i++)
        {
            var start = cursor.AddDays(i * 7);
            var end = start.AddDays(7);
            weeks.Add(new WeeklyCount
            {
                WeekStart = start.ToString("dd MMM"),
                Count = successes.Count(d => d >= start && d < end)
            });
        }

        return Ok(new ReportDto
        {
            TotalClients = await _db.Clients.CountAsync(),
            ActiveClients = await _db.Clients.CountAsync(c => c.IsActive),
            InactiveClients = await _db.Clients.CountAsync(c => !c.IsActive),
            SuccessfulBackups = await _db.Backups.CountAsync(b => b.UploadStatus == BackupStatuses.Success),
            FailedBackups = await _db.UploadSessions.CountAsync(s => s.Status == SessionStatuses.Failed),
            PendingVerification = await _db.Backups.CountAsync(b => b.VerificationStatus == VerificationStatuses.PendingVerification && b.UploadStatus == BackupStatuses.Success),
            Verified = await _db.Backups.CountAsync(b => b.VerificationStatus == VerificationStatuses.Verified),
            VerificationFailed = await _db.Backups.CountAsync(b => b.VerificationStatus == VerificationStatuses.VerificationFailed),
            StorageUsedBytes = used,
            TopClients = top,
            WeeklyTrend = weeks
        });
    }
}
