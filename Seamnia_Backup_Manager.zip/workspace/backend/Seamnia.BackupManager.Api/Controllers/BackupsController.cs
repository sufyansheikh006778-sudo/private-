using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Seamnia.BackupManager.Api.Data;
using Seamnia.BackupManager.Api.Models;
using Seamnia.BackupManager.Api.Services;

namespace Seamnia.BackupManager.Api.Controllers;

[ApiController]
[Route("api/backups")]
[Authorize]
public class BackupsController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly StorageService _storage;
    private readonly AuditService _audit;
    private readonly VerificationService _verify;

    public BackupsController(AppDbContext db, StorageService storage, AuditService audit, VerificationService verify)
    {
        _db = db;
        _storage = storage;
        _audit = audit;
        _verify = verify;
    }

    [HttpGet]
    public async Task<ActionResult<PagedResult<BackupDto>>> List(
        [FromQuery] string? q,
        [FromQuery] int? clientId,
        [FromQuery] string? status,
        [FromQuery] string? verification,
        [FromQuery] DateTimeOffset? from,
        [FromQuery] DateTimeOffset? to,
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 25)
    {
        page = Math.Max(1, page);
        pageSize = Math.Clamp(pageSize, 1, 100);

        var query = _db.Backups.Include(b => b.Client).AsQueryable();
        var role = User.FindFirstValue(ClaimTypes.Role);
        if (role == UserRoles.Client)
        {
            var cid = int.Parse(User.FindFirstValue("clientId") ?? "0");
            query = query.Where(b => b.ClientId == cid);
        }
        else if (clientId.HasValue)
        {
            query = query.Where(b => b.ClientId == clientId.Value);
        }

        if (!string.IsNullOrWhiteSpace(q))
        {
            var term = q.Trim().ToLower();
            query = query.Where(b =>
                b.OriginalFileName.ToLower().Contains(term) ||
                b.Client.CompanyName.ToLower().Contains(term) ||
                b.Client.Code.ToLower().Contains(term) ||
                (b.Remarks != null && b.Remarks.ToLower().Contains(term)) ||
                b.Sha256Hash.ToLower().Contains(term));
        }
        if (!string.IsNullOrWhiteSpace(status))
            query = query.Where(b => b.UploadStatus == status);
        if (!string.IsNullOrWhiteSpace(verification))
            query = query.Where(b => b.VerificationStatus == verification);
        if (from.HasValue)
            query = query.Where(b => b.CreatedAt >= from.Value);
        if (to.HasValue)
            query = query.Where(b => b.CreatedAt <= to.Value);

        var total = await query.CountAsync();
        var items = await query.OrderByDescending(b => b.CreatedAt).Skip((page - 1) * pageSize).Take(pageSize).ToListAsync();
        return Ok(new PagedResult<BackupDto>
        {
            Items = items.Select(Map).ToList(),
            Total = total,
            Page = page,
            PageSize = pageSize
        });
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<BackupDto>> Get(int id)
    {
        var backup = await OwnedBackup(id);
        if (backup == null) return NotFound();
        return Ok(Map(backup));
    }

    [HttpGet("{id:int}/download")]
    public async Task<IActionResult> Download(int id)
    {
        var backup = await OwnedBackup(id);
        if (backup == null) return NotFound();
        if (backup.UploadStatus != BackupStatuses.Success)
            return BadRequest(new { message = "Only successful backups can be downloaded." });
        if (!System.IO.File.Exists(backup.StoragePath))
            return NotFound(new { message = "File is missing from storage." });

        await _audit.LogAsync(CurrentUserId(), User.Identity?.Name ?? "", User.FindFirstValue(ClaimTypes.Role) ?? "",
            "DownloadBackup", "Backup", id.ToString(), backup.OriginalFileName);

        var stream = _storage.OpenRead(backup.StoragePath);
        return File(stream, "application/octet-stream", backup.OriginalFileName);
    }

    [HttpDelete("{id:int}")]
    [Authorize(Roles = UserRoles.SuperAdmin)]
    public async Task<IActionResult> Delete(int id)
    {
        var backup = await _db.Backups.Include(b => b.Client).FirstOrDefaultAsync(b => b.Id == id);
        if (backup == null) return NotFound();
        _storage.DeleteFile(backup.StoragePath);
        _db.Backups.Remove(backup);
        await _db.SaveChangesAsync();
        await _audit.LogAsync(CurrentUserId(), User.Identity?.Name ?? "", UserRoles.SuperAdmin, "DeleteBackup", "Backup", id.ToString(),
            $"{backup.Client.Code} {backup.OriginalFileName}");
        return Ok(new { message = "Backup deleted." });
    }

    [HttpPost("{id:int}/verify")]
    [Authorize(Roles = $"{UserRoles.SuperAdmin},{UserRoles.Admin}")]
    public async Task<ActionResult<BackupDto>> Verify(int id, CancellationToken ct)
    {
        var backup = await _db.Backups.Include(b => b.Client).FirstOrDefaultAsync(b => b.Id == id, ct);
        if (backup == null) return NotFound();
        await _verify.VerifyBackupAsync(id, ct);
        backup = await _db.Backups.Include(b => b.Client).FirstAsync(b => b.Id == id, ct);
        await _audit.LogAsync(CurrentUserId(), User.Identity?.Name ?? "", User.FindFirstValue(ClaimTypes.Role) ?? "",
            "VerifyBackup", "Backup", id.ToString(), backup.VerificationStatus);
        return Ok(Map(backup));
    }

    private async Task<Backup?> OwnedBackup(int id)
    {
        var backup = await _db.Backups.Include(b => b.Client).FirstOrDefaultAsync(b => b.Id == id);
        if (backup == null) return null;
        var role = User.FindFirstValue(ClaimTypes.Role);
        if (role is UserRoles.SuperAdmin or UserRoles.Admin)
            return backup;
        var clientId = int.Parse(User.FindFirstValue("clientId") ?? "0");
        return backup.ClientId == clientId ? backup : null;
    }

    private int CurrentUserId() => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    private static BackupDto Map(Backup b) => new()
    {
        Id = b.Id,
        ClientId = b.ClientId,
        ClientName = b.Client?.CompanyName ?? "",
        ClientCode = b.Client?.Code ?? "",
        OriginalFileName = b.OriginalFileName,
        FileSizeBytes = b.FileSizeBytes,
        Sha256Hash = b.Sha256Hash,
        Remarks = b.Remarks,
        UploadStatus = b.UploadStatus,
        VerificationStatus = b.VerificationStatus,
        VerificationMessage = b.VerificationMessage,
        CreatedAt = b.CreatedAt,
        CompletedAt = b.CompletedAt,
        UsedQuotaOverride = b.UsedQuotaOverride
    };
}
