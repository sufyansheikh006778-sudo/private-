using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Seamnia.BackupManager.Api.Data;
using Seamnia.BackupManager.Api.Models;
using Seamnia.BackupManager.Api.Services;

namespace Seamnia.BackupManager.Api.Controllers;

[ApiController]
[Route("api/settings")]
[Authorize(Roles = UserRoles.SuperAdmin)]
public class SettingsController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly AuditService _audit;

    public SettingsController(AppDbContext db, AuditService audit)
    {
        _db = db;
        _audit = audit;
    }

    [HttpGet]
    public async Task<ActionResult<List<SettingDto>>> List()
    {
        var items = await _db.SystemSettings.OrderBy(s => s.Key).ToListAsync();
        return Ok(items.Select(s => new SettingDto
        {
            Key = s.Key,
            Value = s.Value,
            Description = s.Description,
            UpdatedAt = s.UpdatedAt
        }).ToList());
    }

    [HttpPut]
    public async Task<IActionResult> Update([FromBody] SettingUpdateRequest req)
    {
        var setting = await _db.SystemSettings.FirstOrDefaultAsync(s => s.Key == req.Key);
        if (setting == null) return NotFound(new { message = "Unknown setting." });
        if (string.IsNullOrWhiteSpace(req.Value))
            return BadRequest(new { message = "Value is required." });

        setting.Value = req.Value.Trim();
        setting.UpdatedAt = PktTime.Now;
        await _db.SaveChangesAsync();
        await _audit.LogAsync(
            int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!),
            User.Identity?.Name ?? "",
            UserRoles.SuperAdmin,
            "UpdateSetting",
            "SystemSetting",
            req.Key,
            $"{req.Key} = {req.Value}");
        return Ok(new SettingDto
        {
            Key = setting.Key,
            Value = setting.Value,
            Description = setting.Description,
            UpdatedAt = setting.UpdatedAt
        });
    }
}
