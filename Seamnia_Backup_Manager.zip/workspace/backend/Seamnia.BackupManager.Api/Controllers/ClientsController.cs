using System.Security.Claims;
using System.Security.Cryptography;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Seamnia.BackupManager.Api.Data;
using Seamnia.BackupManager.Api.Models;
using Seamnia.BackupManager.Api.Services;

namespace Seamnia.BackupManager.Api.Controllers;

[ApiController]
[Route("api/clients")]
[Authorize(Roles = $"{UserRoles.SuperAdmin},{UserRoles.Admin}")]
public class ClientsController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly AuditService _audit;
    private readonly StorageService _storage;

    public ClientsController(AppDbContext db, AuditService audit, StorageService storage)
    {
        _db = db;
        _audit = audit;
        _storage = storage;
    }

    [HttpGet]
    public async Task<ActionResult<PagedResult<ClientDto>>> List([FromQuery] string? q, [FromQuery] bool? active, [FromQuery] int page = 1, [FromQuery] int pageSize = 25)
    {
        page = Math.Max(1, page);
        pageSize = Math.Clamp(pageSize, 1, 100);
        var query = _db.Clients.Include(c => c.Users).Include(c => c.Backups).AsQueryable();
        if (!string.IsNullOrWhiteSpace(q))
        {
            var term = q.Trim().ToLower();
            query = query.Where(c =>
                c.CompanyName.ToLower().Contains(term) ||
                c.Code.ToLower().Contains(term) ||
                c.ContactName.ToLower().Contains(term) ||
                c.ContactEmail.ToLower().Contains(term) ||
                c.Users.Any(u => u.Username.ToLower().Contains(term)));
        }
        if (active.HasValue)
            query = query.Where(c => c.IsActive == active.Value);

        var total = await query.CountAsync();
        var items = await query.OrderBy(c => c.Code).Skip((page - 1) * pageSize).Take(pageSize).ToListAsync();
        return Ok(new PagedResult<ClientDto>
        {
            Items = items.Select(Map).ToList(),
            Total = total,
            Page = page,
            PageSize = pageSize
        });
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<ClientDto>> Get(int id)
    {
        var client = await _db.Clients.Include(c => c.Users).Include(c => c.Backups).FirstOrDefaultAsync(c => c.Id == id);
        if (client == null) return NotFound();
        return Ok(Map(client));
    }

    [HttpPost]
    [Authorize(Roles = UserRoles.SuperAdmin)]
    public async Task<ActionResult<object>> Create([FromBody] CreateClientRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.CompanyName))
            return BadRequest(new { message = "Company name is required." });

        var nextNum = (await _db.Clients.CountAsync()) + 1;
        string code;
        do
        {
            code = $"Client_{nextNum:D3}";
            nextNum++;
        } while (await _db.Clients.AnyAsync(c => c.Code == code));

        var username = string.IsNullOrWhiteSpace(req.Username)
            ? GenerateUsername(req.CompanyName)
            : req.Username.Trim();
        if (await _db.Users.AnyAsync(u => u.Username == username))
            username = username + nextNum;

        var password = string.IsNullOrWhiteSpace(req.Password) ? GeneratePassword() : req.Password;

        var client = new Client
        {
            Code = code,
            CompanyName = req.CompanyName.Trim(),
            ContactName = req.ContactName?.Trim() ?? "",
            ContactEmail = req.ContactEmail?.Trim() ?? "",
            ContactPhone = req.ContactPhone?.Trim() ?? "",
            StorageFolder = code,
            IsActive = true,
            CreatedAt = PktTime.Now
        };
        _db.Clients.Add(client);
        await _db.SaveChangesAsync();
        _storage.EnsureClientFolder(client.StorageFolder);

        var user = new User
        {
            Username = username,
            PasswordHash = BCrypt.Net.BCrypt.HashPassword(password),
            FullName = req.ContactName?.Trim() ?? req.CompanyName.Trim(),
            Email = req.ContactEmail?.Trim() ?? "",
            Role = UserRoles.Client,
            IsActive = true,
            ClientId = client.Id,
            CreatedAt = PktTime.Now,
            MustChangePassword = true
        };
        _db.Users.Add(user);
        await _db.SaveChangesAsync();
        await _audit.LogAsync(CurrentUserId(), User.Identity?.Name ?? "", CurrentRole(), "CreateClient", "Client", client.Id.ToString(), $"Created {client.Code} / {client.CompanyName}");

        var dto = Map(await _db.Clients.Include(c => c.Users).Include(c => c.Backups).FirstAsync(c => c.Id == client.Id));
        return Ok(new { client = dto, credentials = new GeneratedCredentials { Username = username, Password = password } });
    }

    [HttpPut("{id:int}")]
    [Authorize(Roles = UserRoles.SuperAdmin)]
    public async Task<ActionResult<ClientDto>> Update(int id, [FromBody] UpdateClientRequest req)
    {
        var client = await _db.Clients.Include(c => c.Users).Include(c => c.Backups).FirstOrDefaultAsync(c => c.Id == id);
        if (client == null) return NotFound();
        if (req.CompanyName != null) client.CompanyName = req.CompanyName.Trim();
        if (req.ContactName != null) client.ContactName = req.ContactName.Trim();
        if (req.ContactEmail != null) client.ContactEmail = req.ContactEmail.Trim();
        if (req.ContactPhone != null) client.ContactPhone = req.ContactPhone.Trim();
        if (req.IsActive.HasValue)
        {
            client.IsActive = req.IsActive.Value;
            client.DeactivatedAt = req.IsActive.Value ? null : PktTime.Now;
            foreach (var u in client.Users.Where(u => u.Role == UserRoles.Client))
                u.IsActive = req.IsActive.Value;
        }
        await _db.SaveChangesAsync();
        await _audit.LogAsync(CurrentUserId(), User.Identity?.Name ?? "", CurrentRole(), "UpdateClient", "Client", id.ToString(), $"Updated {client.Code}");
        return Ok(Map(client));
    }

    [HttpPost("{id:int}/reset-password")]
    [Authorize(Roles = UserRoles.SuperAdmin)]
    public async Task<ActionResult<GeneratedCredentials>> ResetPassword(int id, [FromBody] ResetPasswordRequest? req)
    {
        var client = await _db.Clients.Include(c => c.Users).FirstOrDefaultAsync(c => c.Id == id);
        if (client == null) return NotFound();
        var user = client.Users.FirstOrDefault(u => u.Role == UserRoles.Client);
        if (user == null) return NotFound(new { message = "Client user not found." });
        var password = string.IsNullOrWhiteSpace(req?.NewPassword) ? GeneratePassword() : req!.NewPassword;
        user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(password);
        user.MustChangePassword = true;
        await _db.SaveChangesAsync();
        await _audit.LogAsync(CurrentUserId(), User.Identity?.Name ?? "", CurrentRole(), "ResetPassword", "User", user.Id.ToString(), $"Reset password for {user.Username}");
        return Ok(new GeneratedCredentials { Username = user.Username, Password = password });
    }

    [HttpPost("{id:int}/override-quota")]
    [Authorize(Roles = $"{UserRoles.SuperAdmin},{UserRoles.Admin}")]
    public async Task<IActionResult> OverrideQuota(int id, [FromBody] OverrideQuotaRequest req)
    {
        var client = await _db.Clients.FindAsync(id);
        if (client == null) return NotFound();
        if (req.ExtraCredits < 1)
            return BadRequest(new { message = "Extra credits must be at least 1." });
        if (string.IsNullOrWhiteSpace(req.Reason))
            return BadRequest(new { message = "A reason is required for quota overrides." });

        client.ExtraUploadCredits += req.ExtraCredits;
        await _db.SaveChangesAsync();
        await _audit.LogAsync(CurrentUserId(), User.Identity?.Name ?? "", CurrentRole(), "OverrideQuota", "Client", id.ToString(),
            $"Granted {req.ExtraCredits} extra weekly upload credit(s) to {client.Code}. Reason: {req.Reason}");
        return Ok(new { extraUploadCredits = client.ExtraUploadCredits });
    }

    private int CurrentUserId() => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
    private string CurrentRole() => User.FindFirstValue(ClaimTypes.Role) ?? "";

    private ClientDto Map(Client c) => new()
    {
        Id = c.Id,
        Code = c.Code,
        CompanyName = c.CompanyName,
        ContactName = c.ContactName,
        ContactEmail = c.ContactEmail,
        ContactPhone = c.ContactPhone,
        StorageFolder = c.StorageFolder,
        IsActive = c.IsActive,
        ExtraUploadCredits = c.ExtraUploadCredits,
        CreatedAt = c.CreatedAt,
        BackupCount = c.Backups?.Count(b => b.UploadStatus == BackupStatuses.Success) ?? 0,
        StorageUsedBytes = c.Backups?.Where(b => b.UploadStatus == BackupStatuses.Success).Sum(b => b.FileSizeBytes) ?? 0,
        LastUploadAt = c.Backups?.Where(b => b.CompletedAt != null).Max(b => b.CompletedAt),
        Username = c.Users?.FirstOrDefault(u => u.Role == UserRoles.Client)?.Username
    };

    private static string GenerateUsername(string company)
    {
        var cleaned = new string(company.ToLowerInvariant().Where(char.IsLetterOrDigit).ToArray());
        if (cleaned.Length > 12) cleaned = cleaned[..12];
        if (string.IsNullOrWhiteSpace(cleaned)) cleaned = "client";
        return cleaned;
    }

    private static string GeneratePassword()
    {
        const string chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$";
        var bytes = RandomNumberGenerator.GetBytes(14);
        return new string(bytes.Select(b => chars[b % chars.Length]).ToArray());
    }
}
