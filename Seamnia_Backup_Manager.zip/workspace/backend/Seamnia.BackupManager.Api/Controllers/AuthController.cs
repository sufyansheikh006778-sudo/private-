using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Seamnia.BackupManager.Api.Data;
using Seamnia.BackupManager.Api.Models;
using Seamnia.BackupManager.Api.Services;

namespace Seamnia.BackupManager.Api.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly TokenService _tokens;
    private readonly AuditService _audit;

    public AuthController(AppDbContext db, TokenService tokens, AuditService audit)
    {
        _db = db;
        _tokens = tokens;
        _audit = audit;
    }

    [HttpPost("login")]
    [AllowAnonymous]
    public async Task<ActionResult<LoginResponse>> Login([FromBody] LoginRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.Username) || string.IsNullOrWhiteSpace(req.Password))
            return BadRequest(new { message = "Username and password are required." });

        var user = await _db.Users.Include(u => u.Client).FirstOrDefaultAsync(u => u.Username == req.Username.Trim());
        if (user == null || !BCrypt.Net.BCrypt.Verify(req.Password, user.PasswordHash))
        {
            await _audit.LogAsync(null, req.Username, "", "LoginFailed", "User", null, "Invalid credentials");
            return Unauthorized(new { message = "Invalid username or password." });
        }

        if (!user.IsActive)
            return Unauthorized(new { message = "Account is deactivated. Contact Seamnia support." });

        if (user.Role == UserRoles.Client && user.Client != null && !user.Client.IsActive)
            return Unauthorized(new { message = "Client account is deactivated." });

        user.LastLoginAt = PktTime.Now;
        await _db.SaveChangesAsync();
        await _audit.LogAsync(user.Id, user.Username, user.Role, "Login", "User", user.Id.ToString(), "Successful login");

        var token = _tokens.Create(user);
        return Ok(new LoginResponse(token, user.Role, user.Username, user.FullName, user.Id, user.ClientId, user.Client?.CompanyName, user.MustChangePassword));
    }

    [HttpGet("me")]
    [Authorize]
    public async Task<ActionResult<LoginResponse>> Me()
    {
        var id = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        var user = await _db.Users.Include(u => u.Client).FirstOrDefaultAsync(u => u.Id == id);
        if (user == null) return Unauthorized();
        var token = _tokens.Create(user);
        return Ok(new LoginResponse(token, user.Role, user.Username, user.FullName, user.Id, user.ClientId, user.Client?.CompanyName, user.MustChangePassword));
    }

    [HttpPost("change-password")]
    [Authorize]
    public async Task<IActionResult> ChangePassword([FromBody] ChangePasswordRequest req)
    {
        var id = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        var user = await _db.Users.FindAsync(id);
        if (user == null) return Unauthorized();
        if (!BCrypt.Net.BCrypt.Verify(req.CurrentPassword, user.PasswordHash))
            return BadRequest(new { message = "Current password is incorrect." });
        if (string.IsNullOrWhiteSpace(req.NewPassword) || req.NewPassword.Length < 8)
            return BadRequest(new { message = "New password must be at least 8 characters." });

        user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(req.NewPassword);
        user.MustChangePassword = false;
        await _db.SaveChangesAsync();
        await _audit.LogAsync(user.Id, user.Username, user.Role, "ChangePassword", "User", user.Id.ToString(), "Password changed");
        return Ok(new { message = "Password updated." });
    }
}
