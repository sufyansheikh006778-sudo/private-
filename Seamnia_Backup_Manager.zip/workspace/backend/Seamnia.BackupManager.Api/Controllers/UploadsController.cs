using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Seamnia.BackupManager.Api.Data;
using Seamnia.BackupManager.Api.Models;
using Seamnia.BackupManager.Api.Services;

namespace Seamnia.BackupManager.Api.Controllers;

[ApiController]
[Route("api/uploads")]
[Authorize]
public class UploadsController : ControllerBase
{
    private const long DefaultMax = 50L * 1024 * 1024 * 1024;
    private const int DefaultChunk = 100 * 1024 * 1024;

    private readonly AppDbContext _db;
    private readonly StorageService _storage;
    private readonly QuotaService _quota;
    private readonly AuditService _audit;
    private readonly VerificationService _verify;

    public UploadsController(AppDbContext db, StorageService storage, QuotaService quota, AuditService audit, VerificationService verify)
    {
        _db = db;
        _storage = storage;
        _quota = quota;
        _audit = audit;
        _verify = verify;
    }

    [HttpPost("start")]
    [Authorize(Roles = UserRoles.Client)]
    public async Task<ActionResult<StartUploadResponse>> Start([FromBody] StartUploadRequest req, CancellationToken ct)
    {
        var user = await CurrentUserAsync();
        if (user?.ClientId == null)
            return Forbid();

        var client = await _db.Clients.FindAsync(new object[] { user.ClientId.Value }, ct);
        if (client == null || !client.IsActive || !user.IsActive)
            return Unauthorized(new { message = "Account is not allowed to upload." });

        if (string.IsNullOrWhiteSpace(req.FileName) || !req.FileName.EndsWith(".bak", StringComparison.OrdinalIgnoreCase))
            return BadRequest(new { message = "Only .BAK files are allowed." });
        if (req.FileName.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
            return BadRequest(new { message = "Invalid file name." });

        var maxSize = await GetLongSetting("MaxFileSizeBytes", DefaultMax);
        if (req.FileSizeBytes <= 0 || req.FileSizeBytes > maxSize)
            return BadRequest(new { message = $"File size must be between 1 byte and {maxSize / (1024L * 1024 * 1024)} GB." });

        var (allowed, message, next, _) = await _quota.CanUploadAsync(client.Id, ct);
        if (!allowed)
            return StatusCode(429, new { message, nextAvailableUpload = next });

        var usedOverride = false;
        var (weekStart, weekEnd) = PktTime.CurrentWeek();
        var already = await _db.Backups.CountAsync(b =>
            b.ClientId == client.Id && b.UploadStatus == BackupStatuses.Success &&
            b.CompletedAt >= weekStart && b.CompletedAt < weekEnd, ct);
        if (already >= 1 && client.ExtraUploadCredits > 0)
            usedOverride = true;

        var chunkSize = await GetIntSetting("ChunkSizeBytes", DefaultChunk);
        if (req.ChunkSizeBytes is > 1024 * 1024 and <= 256 * 1024 * 1024)
            chunkSize = req.ChunkSizeBytes.Value;

        var totalChunks = (int)Math.Ceiling(req.FileSizeBytes / (double)chunkSize);
        var hours = await GetIntSetting("SessionExpiryHours", 72);

        var session = new UploadSession
        {
            ClientId = client.Id,
            UserId = user.Id,
            OriginalFileName = Path.GetFileName(req.FileName),
            FileSizeBytes = req.FileSizeBytes,
            ChunkSizeBytes = chunkSize,
            TotalChunks = totalChunks,
            Status = SessionStatuses.Active,
            Remarks = req.Remarks,
            TempDirectory = "",
            CreatedAt = PktTime.Now,
            ExpiresAt = PktTime.Now.AddHours(hours)
        };
        _db.UploadSessions.Add(session);
        await _db.SaveChangesAsync(ct);
        session.TempDirectory = _storage.GetSessionPath(client.StorageFolder, session.Id);
        await _db.SaveChangesAsync(ct);

        await _audit.LogAsync(user.Id, user.Username, user.Role, "StartUpload", "UploadSession", session.Id.ToString(),
            $"{session.OriginalFileName} ({session.FileSizeBytes} bytes)" + (usedOverride ? " [override]" : ""));

        return Ok(new StartUploadResponse(session.Id, chunkSize, totalChunks, new List<int>(), usedOverride, next));
    }

    [HttpGet("{sessionId:int}")]
    public async Task<ActionResult<SessionDto>> GetSession(int sessionId)
    {
        var session = await LoadOwnedSession(sessionId);
        if (session == null) return NotFound();
        return Ok(MapSession(session));
    }

    [HttpPut("{sessionId:int}/chunks/{index:int}")]
    [Authorize(Roles = UserRoles.Client)]
    [RequestSizeLimit(300_000_000)]
    [RequestFormLimits(MultipartBodyLengthLimit = 300_000_000)]
    public async Task<IActionResult> PutChunk(int sessionId, int index, CancellationToken ct)
    {
        var session = await LoadOwnedSession(sessionId);
        if (session == null) return NotFound();
        if (session.Status != SessionStatuses.Active)
            return BadRequest(new { message = "Upload session is not active." });
        if (PktTime.Now > session.ExpiresAt)
        {
            session.Status = SessionStatuses.Failed;
            session.ErrorMessage = "Session expired.";
            await _db.SaveChangesAsync(ct);
            return BadRequest(new { message = "Upload session expired." });
        }
        if (index < 0 || index >= session.TotalChunks)
            return BadRequest(new { message = "Invalid chunk index." });

        if (Request.ContentLength is null or <= 0)
            return BadRequest(new { message = "Empty chunk." });

        var expected = index == session.TotalChunks - 1
            ? session.FileSizeBytes - (long)session.ChunkSizeBytes * (session.TotalChunks - 1)
            : session.ChunkSizeBytes;
        if (Request.ContentLength > session.ChunkSizeBytes + 1024)
            return BadRequest(new { message = "Chunk exceeds configured size." });

        var client = session.Client;
        await _storage.WriteChunkAsync(client.StorageFolder, session.Id, index, Request.Body, ct);

        var existing = await _db.UploadChunks.FirstOrDefaultAsync(c => c.UploadSessionId == session.Id && c.ChunkIndex == index, ct);
        var info = new FileInfo(_storage.GetChunkPath(client.StorageFolder, session.Id, index));
        if (existing == null)
        {
            _db.UploadChunks.Add(new UploadChunk
            {
                UploadSessionId = session.Id,
                ChunkIndex = index,
                ChunkSizeBytes = info.Length,
                ReceivedAt = PktTime.Now
            });
        }
        else
        {
            existing.ChunkSizeBytes = info.Length;
            existing.ReceivedAt = PktTime.Now;
        }
        await _db.SaveChangesAsync(ct);

        var received = await _db.UploadChunks.CountAsync(c => c.UploadSessionId == session.Id, ct);
        return Ok(new { index, received, total = session.TotalChunks, expected });
    }

    [HttpPost("{sessionId:int}/complete")]
    [Authorize(Roles = UserRoles.Client)]
    public async Task<ActionResult<BackupDto>> Complete(int sessionId, [FromBody] CompleteUploadRequest? req, CancellationToken ct)
    {
        var session = await LoadOwnedSession(sessionId);
        if (session == null) return NotFound();
        if (session.Status != SessionStatuses.Active)
            return BadRequest(new { message = "Upload session is not active." });

        var received = await _db.UploadChunks.Where(c => c.UploadSessionId == session.Id).Select(c => c.ChunkIndex).ToListAsync(ct);
        if (received.Count != session.TotalChunks)
        {
            session.Status = SessionStatuses.Failed;
            session.ErrorMessage = $"Incomplete upload: {received.Count}/{session.TotalChunks} chunks.";
            await _db.SaveChangesAsync(ct);
            return BadRequest(new { message = session.ErrorMessage, received });
        }

        var client = session.Client;
        var storedName = _storage.BuildStoredFileName(session.OriginalFileName);

        string path;
        long size;
        string hash;
        try
        {
            (path, size, hash) = await _storage.AssembleAsync(client.StorageFolder, session.Id, session.TotalChunks, storedName, ct);
        }
        catch (Exception ex)
        {
            session.Status = SessionStatuses.Failed;
            session.ErrorMessage = "Reassembly failed: " + ex.Message;
            await _db.SaveChangesAsync(ct);
            return BadRequest(new { message = session.ErrorMessage });
        }

        if (size != session.FileSizeBytes)
        {
            _storage.DeleteFile(path);
            session.Status = SessionStatuses.Failed;
            session.ErrorMessage = $"Assembled size {size} does not match declared size {session.FileSizeBytes}.";
            await _db.SaveChangesAsync(ct);
            return BadRequest(new { message = session.ErrorMessage });
        }

        if (!string.IsNullOrWhiteSpace(req?.ClientSha256) &&
            !string.Equals(req.ClientSha256, hash, StringComparison.OrdinalIgnoreCase))
        {
            _storage.DeleteFile(path);
            session.Status = SessionStatuses.Failed;
            session.ErrorMessage = "SHA-256 mismatch between client and server.";
            await _db.SaveChangesAsync(ct);
            return BadRequest(new { message = session.ErrorMessage });
        }

        var duplicate = await _db.Backups.Include(b => b.Client).FirstOrDefaultAsync(b =>
            b.ClientId == client.Id && b.Sha256Hash == hash && b.UploadStatus == BackupStatuses.Success, ct);

        var (allowed, message, _, _) = await _quota.CanUploadAsync(client.Id, ct);
        if (!allowed)
        {
            _storage.DeleteFile(path);
            session.Status = SessionStatuses.Failed;
            session.ErrorMessage = message;
            await _db.SaveChangesAsync(ct);
            return StatusCode(429, new { message });
        }

        var (weekStart, weekEnd) = PktTime.CurrentWeek();
        var already = await _db.Backups.CountAsync(b =>
            b.ClientId == client.Id && b.UploadStatus == BackupStatuses.Success &&
            b.CompletedAt >= weekStart && b.CompletedAt < weekEnd, ct);
        var usedOverride = already >= 1 && client.ExtraUploadCredits > 0;

        var backup = new Backup
        {
            ClientId = client.Id,
            UploadedByUserId = session.UserId,
            OriginalFileName = session.OriginalFileName,
            StoredFileName = storedName,
            StoragePath = path,
            FileSizeBytes = size,
            Sha256Hash = hash,
            Remarks = session.Remarks,
            UploadStatus = BackupStatuses.Success,
            VerificationStatus = VerificationStatuses.PendingVerification,
            CreatedAt = session.CreatedAt,
            CompletedAt = PktTime.Now,
            UsedQuotaOverride = usedOverride,
            UploadSessionId = session.Id
        };
        _db.Backups.Add(backup);
        session.Status = SessionStatuses.Completed;
        session.CompletedAt = backup.CompletedAt;
        await _db.SaveChangesAsync(ct);

        if (usedOverride)
            await _quota.ConsumeOverrideIfNeededAsync(client.Id, true);

        _storage.CleanupSession(client.StorageFolder, session.Id);

        await _audit.LogAsync(session.UserId, User.Identity?.Name ?? "", UserRoles.Client, "UploadComplete", "Backup", backup.Id.ToString(),
            $"{backup.OriginalFileName} sha256={hash}" + (duplicate != null ? " (duplicate content of backup #" + duplicate.Id + ")" : "") +
            (usedOverride ? " [quota override]" : ""));

        _ = Task.Run(async () =>
        {
            try { await _verify.VerifyBackupAsync(backup.Id, CancellationToken.None); }
            catch { /* logged inside service */ }
        });

        backup.Client = client;
        return Ok(MapBackup(backup));
    }

    [HttpPost("{sessionId:int}/cancel")]
    [Authorize(Roles = UserRoles.Client)]
    public async Task<IActionResult> Cancel(int sessionId)
    {
        var session = await LoadOwnedSession(sessionId);
        if (session == null) return NotFound();
        if (session.Status != SessionStatuses.Active)
            return BadRequest(new { message = "Session is not active." });

        session.Status = SessionStatuses.Cancelled;
        session.CompletedAt = PktTime.Now;
        session.ErrorMessage = "Cancelled by user.";
        await _db.SaveChangesAsync();
        _storage.CleanupSession(session.Client.StorageFolder, session.Id);
        await _audit.LogAsync(session.UserId, User.Identity?.Name ?? "", UserRoles.Client, "UploadCancel", "UploadSession", session.Id.ToString(), session.OriginalFileName);
        return Ok(new { message = "Upload cancelled." });
    }

    [HttpGet("active")]
    [Authorize(Roles = $"{UserRoles.SuperAdmin},{UserRoles.Admin}")]
    public async Task<ActionResult<List<SessionDto>>> Active()
    {
        var sessions = await _db.UploadSessions.Include(s => s.Client).Include(s => s.Chunks)
            .Where(s => s.Status == SessionStatuses.Active)
            .OrderByDescending(s => s.CreatedAt)
            .Take(200)
            .ToListAsync();
        return Ok(sessions.Select(MapSession).ToList());
    }

    [HttpGet("monitoring")]
    [Authorize(Roles = $"{UserRoles.SuperAdmin},{UserRoles.Admin}")]
    public async Task<ActionResult<PagedResult<SessionDto>>> Monitoring([FromQuery] string? status, [FromQuery] int page = 1, [FromQuery] int pageSize = 25)
    {
        page = Math.Max(1, page);
        pageSize = Math.Clamp(pageSize, 1, 100);
        var q = _db.UploadSessions.Include(s => s.Client).Include(s => s.Chunks).AsQueryable();
        if (!string.IsNullOrWhiteSpace(status))
            q = q.Where(s => s.Status == status);
        var total = await q.CountAsync();
        var items = await q.OrderByDescending(s => s.CreatedAt).Skip((page - 1) * pageSize).Take(pageSize).ToListAsync();
        return Ok(new PagedResult<SessionDto> { Items = items.Select(MapSession).ToList(), Total = total, Page = page, PageSize = pageSize });
    }

    private async Task<User?> CurrentUserAsync()
    {
        var id = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        return await _db.Users.Include(u => u.Client).FirstOrDefaultAsync(u => u.Id == id);
    }

    private async Task<UploadSession?> LoadOwnedSession(int sessionId)
    {
        var session = await _db.UploadSessions.Include(s => s.Client).Include(s => s.Chunks)
            .FirstOrDefaultAsync(s => s.Id == sessionId);
        if (session == null) return null;
        var role = User.FindFirstValue(ClaimTypes.Role);
        if (role is UserRoles.SuperAdmin or UserRoles.Admin)
            return session;
        var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        var clientIdClaim = User.FindFirstValue("clientId");
        if (!int.TryParse(clientIdClaim, out var clientId) || session.ClientId != clientId || session.UserId != userId)
            return null;
        return session;
    }

    private async Task<long> GetLongSetting(string key, long fallback)
    {
        var s = await _db.SystemSettings.FirstOrDefaultAsync(x => x.Key == key);
        return s != null && long.TryParse(s.Value, out var v) ? v : fallback;
    }

    private async Task<int> GetIntSetting(string key, int fallback)
    {
        var s = await _db.SystemSettings.FirstOrDefaultAsync(x => x.Key == key);
        return s != null && int.TryParse(s.Value, out var v) ? v : fallback;
    }

    private static SessionDto MapSession(UploadSession s) => new()
    {
        Id = s.Id,
        ClientId = s.ClientId,
        ClientName = s.Client?.CompanyName ?? "",
        OriginalFileName = s.OriginalFileName,
        FileSizeBytes = s.FileSizeBytes,
        ChunkSizeBytes = s.ChunkSizeBytes,
        TotalChunks = s.TotalChunks,
        ReceivedChunks = s.Chunks?.Count ?? 0,
        Status = s.Status,
        Remarks = s.Remarks,
        ErrorMessage = s.ErrorMessage,
        CreatedAt = s.CreatedAt,
        ExpiresAt = s.ExpiresAt
    };

    private static BackupDto MapBackup(Backup b) => new()
    {
        Id = b.Id,
        ClientId = b.ClientId,
        ClientName = b.Client?.CompanyName ?? "",
        ClientCode = b.Client?.Code ?? "",
        OriginalFileName = b.OriginalFileName,
        FileSizeBytes = b.FileSizeBytes,
        Sha256Hash = b.Sha256Hash,
        Remarks = b.Remarks,
        UploadStatus = b.UploadStatus,
        VerificationStatus = b.VerificationStatus,
        VerificationMessage = b.VerificationMessage,
        CreatedAt = b.CreatedAt,
        CompletedAt = b.CompletedAt,
        UsedQuotaOverride = b.UsedQuotaOverride
    };
}
