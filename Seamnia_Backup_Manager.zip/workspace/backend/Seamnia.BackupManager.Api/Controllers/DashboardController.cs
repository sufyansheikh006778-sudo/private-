using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Seamnia.BackupManager.Api.Data;
using Seamnia.BackupManager.Api.Models;
using Seamnia.BackupManager.Api.Services;

namespace Seamnia.BackupManager.Api.Controllers;

[ApiController]
[Route("api/dashboard")]
[Authorize]
public class DashboardController : ControllerBase
{
    private readonly AppDbContext _db;

    public DashboardController(AppDbContext db)
    {
        _db = db;
    }

    [HttpGet("admin")]
    [Authorize(Roles = $"{UserRoles.SuperAdmin},{UserRoles.Admin}")]
    public async Task<ActionResult<DashboardStatsDto>> Admin()
    {
        var (start, end) = PktTime.CurrentWeek();
        var totalStorage = await GetLong("TotalStorageBytes", 20L * 1024 * 1024 * 1024 * 1024);
        var used = await _db.Backups.Where(b => b.UploadStatus == BackupStatuses.Success).SumAsync(b => (long?)b.FileSizeBytes) ?? 0;
        var latest = await _db.Backups.Include(b => b.Client).OrderByDescending(b => b.CreatedAt).Take(8).ToListAsync();

        return Ok(new DashboardStatsDto
        {
            TotalClients = await _db.Clients.CountAsync(),
            ActiveClients = await _db.Clients.CountAsync(c => c.IsActive),
            TotalBackups = await _db.Backups.CountAsync(b => b.UploadStatus == BackupStatuses.Success),
            StorageUsedBytes = used,
            AvailableStorageBytes = Math.Max(0, totalStorage - used),
            WeeklyUploads = await _db.Backups.CountAsync(b => b.UploadStatus == BackupStatuses.Success && b.CompletedAt >= start && b.CompletedAt < end),
            PendingBackups = await _db.UploadSessions.CountAsync(s => s.Status == SessionStatuses.Active) +
                             await _db.Backups.CountAsync(b => b.VerificationStatus == VerificationStatuses.PendingVerification && b.UploadStatus == BackupStatuses.Success),
            FailedUploads = await _db.Backups.CountAsync(b => b.UploadStatus == BackupStatuses.Failed) +
                            await _db.UploadSessions.CountAsync(s => s.Status == SessionStatuses.Failed),
            LatestUploads = latest.Select(MapBackup).ToList()
        });
    }

    [HttpGet("client")]
    [Authorize(Roles = UserRoles.Client)]
    public async Task<ActionResult<ClientDashboardDto>> ClientDash()
    {
        var clientId = int.Parse(User.FindFirstValue("clientId") ?? "0");
        var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        var client = await _db.Clients.FindAsync(clientId);
        var user = await _db.Users.FindAsync(userId);
        if (client == null || user == null) return Unauthorized();

        var backups = _db.Backups.Where(b => b.ClientId == clientId);
        var last = await backups.Where(b => b.UploadStatus == BackupStatuses.Success).OrderByDescending(b => b.CompletedAt).FirstOrDefaultAsync();
        var latestAny = await backups.OrderByDescending(b => b.CreatedAt).FirstOrDefaultAsync();
        var (allowed, message, next, _) = await new QuotaService(_db).CanUploadAsync(clientId, CancellationToken.None);

        return Ok(new ClientDashboardDto
        {
            CompanyName = client.CompanyName,
            FullName = user.FullName,
            TotalBackups = await backups.CountAsync(b => b.UploadStatus == BackupStatuses.Success),
            LastUploadAt = last?.CompletedAt,
            LatestStatus = latestAny?.UploadStatus,
            NextAvailableUpload = next,
            CanUpload = allowed && client.IsActive,
            QuotaMessage = message,
            ExtraUploadCredits = client.ExtraUploadCredits,
            StorageUsedBytes = await backups.Where(b => b.UploadStatus == BackupStatuses.Success).SumAsync(b => (long?)b.FileSizeBytes) ?? 0
        });
    }

    [HttpGet("storage")]
    [Authorize(Roles = $"{UserRoles.SuperAdmin},{UserRoles.Admin}")]
    public async Task<IActionResult> Storage()
    {
        var totalStorage = await GetLong("TotalStorageBytes", 20L * 1024 * 1024 * 1024 * 1024);
        var clients = await _db.Clients.Select(c => new
        {
            c.Id,
            c.Code,
            c.CompanyName,
            c.IsActive,
            BackupCount = c.Backups.Count(b => b.UploadStatus == BackupStatuses.Success),
            StorageUsedBytes = c.Backups.Where(b => b.UploadStatus == BackupStatuses.Success).Sum(b => (long?)b.FileSizeBytes) ?? 0
        }).OrderByDescending(c => c.StorageUsedBytes).ToListAsync();
        var used = clients.Sum(c => c.StorageUsedBytes);
        return Ok(new
        {
            totalStorageBytes = totalStorage,
            usedBytes = used,
            availableBytes = Math.Max(0, totalStorage - used),
            clients
        });
    }

    private async Task<long> GetLong(string key, long fallback)
    {
        var s = await _db.SystemSettings.FirstOrDefaultAsync(x => x.Key == key);
        return s != null && long.TryParse(s.Value, out var v) ? v : fallback;
    }

    private static BackupDto MapBackup(Backup b) => new()
    {
        Id = b.Id,
        ClientId = b.ClientId,
        ClientName = b.Client?.CompanyName ?? "",
        ClientCode = b.Client?.Code ?? "",
        OriginalFileName = b.OriginalFileName,
        FileSizeBytes = b.FileSizeBytes,
        Sha256Hash = b.Sha256Hash,
        Remarks = b.Remarks,
        UploadStatus = b.UploadStatus,
        VerificationStatus = b.VerificationStatus,
        VerificationMessage = b.VerificationMessage,
        CreatedAt = b.CreatedAt,
        CompletedAt = b.CompletedAt,
        UsedQuotaOverride = b.UsedQuotaOverride
    };
}
