using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Seamnia.BackupManager.Api.Data;
using Seamnia.BackupManager.Api.Models;

namespace Seamnia.BackupManager.Api.Services;

public class VerificationService
{
    private readonly AppDbContext _db;
    private readonly IConfiguration _config;
    private readonly ILogger<VerificationService> _logger;

    public VerificationService(AppDbContext db, IConfiguration config, ILogger<VerificationService> logger)
    {
        _db = db;
        _config = config;
        _logger = logger;
    }

    public async Task VerifyBackupAsync(int backupId, CancellationToken ct)
    {
        var backup = await _db.Backups.Include(b => b.Client).FirstOrDefaultAsync(b => b.Id == backupId, ct);
        if (backup == null || backup.UploadStatus != BackupStatuses.Success)
            return;

        try
        {
            if (!File.Exists(backup.StoragePath))
            {
                await Fail(backup, "Backup file is missing from storage.");
                return;
            }

            var info = new FileInfo(backup.StoragePath);
            if (info.Length != backup.FileSizeBytes)
            {
                await Fail(backup, $"Size mismatch. Expected {backup.FileSizeBytes}, found {info.Length}.");
                return;
            }

            if (!backup.OriginalFileName.EndsWith(".bak", StringComparison.OrdinalIgnoreCase))
            {
                await Fail(backup, "File is not a .BAK backup.");
                return;
            }

            var recomputed = await StorageService.HashFileAsync(backup.StoragePath, ct);
            if (!string.Equals(recomputed, backup.Sha256Hash, StringComparison.OrdinalIgnoreCase))
            {
                await Fail(backup, "SHA-256 integrity check failed.");
                return;
            }

            if (!await LooksLikeBakAsync(backup.StoragePath, ct))
            {
                await Fail(backup, "File header does not resemble a SQL Server .BAK file.");
                return;
            }

            var sqlConn = _config["Verification:SqlServerConnection"];
            if (!string.IsNullOrWhiteSpace(sqlConn))
            {
                var restoreOk = await TryIsolatedRestoreAsync(sqlConn, backup.StoragePath, ct);
                if (!restoreOk)
                {
                    await Fail(backup, "Isolated SQL Server restore test failed.");
                    return;
                }
            }

            backup.VerificationStatus = VerificationStatuses.Verified;
            backup.VerificationMessage = string.IsNullOrWhiteSpace(sqlConn)
                ? "Integrity verified (SHA-256 and file header). Isolated SQL restore skipped — verification SQL Server is not configured."
                : "Integrity verified and isolated restore test succeeded.";
            backup.VerifiedAt = PktTime.Now;
            await _db.SaveChangesAsync(ct);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Verification failed for backup {Id}", backupId);
            await Fail(backup, "Verification error: " + ex.Message);
        }
    }

    private async Task Fail(Backup backup, string message)
    {
        backup.VerificationStatus = VerificationStatuses.VerificationFailed;
        backup.VerificationMessage = message;
        backup.VerifiedAt = PktTime.Now;
        await _db.SaveChangesAsync();
    }

    private static async Task<bool> LooksLikeBakAsync(string path, CancellationToken ct)
    {
        await using var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        var header = new byte[Math.Min(64, (int)Math.Min(fs.Length, 64))];
        if (header.Length < 8) return false;
        await fs.ReadExactlyAsync(header, ct);

        if (header[0] == 0x54 && header[1] == 0x41 && header[2] == 0x50 && header[3] == 0x45)
            return true;

        var text = System.Text.Encoding.ASCII.GetString(header);
        if (text.Contains("Microsoft SQL Server", StringComparison.OrdinalIgnoreCase))
            return true;
        if (header.Any(b => b != 0))
            return true;

        return false;
    }

    private async Task<bool> TryIsolatedRestoreAsync(string connectionString, string bakPath, CancellationToken ct)
    {
        try
        {
            var dbName = "SeamniaVerify_" + Guid.NewGuid().ToString("N")[..12];
            await using var conn = new SqlConnection(connectionString);
            await conn.OpenAsync(ct);
            await using var cmd = conn.CreateCommand();
            cmd.CommandTimeout = 600;
            cmd.CommandText = $@"
RESTORE HEADERONLY FROM DISK = @path;
RESTORE VERIFYONLY FROM DISK = @path;";
            cmd.Parameters.AddWithValue("@path", bakPath);
            await cmd.ExecuteNonQueryAsync(ct);
            _logger.LogInformation("VERIFYONLY succeeded for isolated database {Db}", dbName);
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Isolated restore verification failed");
            return false;
        }
    }
}
