using Seamnia.BackupManager.Api.Data;
using Seamnia.BackupManager.Api.Models;

namespace Seamnia.BackupManager.Api.Services;

public class AuditService
{
    private readonly AppDbContext _db;
    private readonly IHttpContextAccessor _http;

    public AuditService(AppDbContext db, IHttpContextAccessor http)
    {
        _db = db;
        _http = http;
    }

    public async Task LogAsync(int? userId, string username, string role, string action, string entityType, string? entityId, string details)
    {
        var ip = _http.HttpContext?.Connection.RemoteIpAddress?.ToString() ?? "";
        _db.AuditLogs.Add(new AuditLog
        {
            UserId = userId,
            Username = username,
            Role = role,
            Action = action,
            EntityType = entityType,
            EntityId = entityId,
            Details = details,
            IpAddress = ip,
            CreatedAt = PktTime.Now
        });
        await _db.SaveChangesAsync();
    }
}
