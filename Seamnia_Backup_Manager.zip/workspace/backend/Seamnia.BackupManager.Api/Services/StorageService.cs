using System.Security.Cryptography;

namespace Seamnia.BackupManager.Api.Services;

public class StorageService
{
    private readonly string _root;
    private readonly ILogger<StorageService> _logger;

    public StorageService(IConfiguration config, ILogger<StorageService> logger)
    {
        _root = config["Storage:RootPath"] ?? Path.Combine(Directory.GetCurrentDirectory(), "SeamniaBackupStorage");
        _logger = logger;
        Directory.CreateDirectory(_root);
    }

    public string RootPath => _root;

    public void EnsureClientFolder(string folder)
    {
        Directory.CreateDirectory(GetClientPath(folder));
    }

    public string GetClientPath(string folder)
    {
        var safe = SanitizeFolder(folder);
        return Path.Combine(_root, safe);
    }

    public string GetSessionPath(string folder, int sessionId)
    {
        var path = Path.Combine(GetClientPath(folder), ".sessions", sessionId.ToString("D8"));
        Directory.CreateDirectory(path);
        return path;
    }

    public string GetChunkPath(string folder, int sessionId, int chunkIndex)
    {
        return Path.Combine(GetSessionPath(folder, sessionId), $"chunk_{chunkIndex:D6}");
    }

    public string BuildStoredFileName(string originalName)
    {
        var stamp = PktTime.Now.ToString("yyyyMMdd_HHmmss");
        var safe = SanitizeFileName(Path.GetFileNameWithoutExtension(originalName));
        return $"{stamp}_{safe}.bak";
    }

    public string GetFinalPath(string folder, string storedFileName)
    {
        return Path.Combine(GetClientPath(folder), storedFileName);
    }

    public async Task WriteChunkAsync(string folder, int sessionId, int chunkIndex, Stream source, CancellationToken ct)
    {
        var path = GetChunkPath(folder, sessionId, chunkIndex);
        await using var fs = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.None, 1024 * 1024, FileOptions.Asynchronous);
        await source.CopyToAsync(fs, ct);
    }

    public bool ChunkExists(string folder, int sessionId, int chunkIndex) =>
        File.Exists(GetChunkPath(folder, sessionId, chunkIndex));

    public async Task<(string path, long size, string sha256)> AssembleAsync(
        string folder, int sessionId, int totalChunks, string storedFileName, CancellationToken ct)
    {
        var finalPath = GetFinalPath(folder, storedFileName);
        await using var dest = new FileStream(finalPath, FileMode.Create, FileAccess.Write, FileShare.None, 1024 * 1024, FileOptions.Asynchronous);
        using var sha = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);

        for (var i = 0; i < totalChunks; i++)
        {
            var chunkPath = GetChunkPath(folder, sessionId, i);
            if (!File.Exists(chunkPath))
                throw new InvalidOperationException($"Missing chunk {i}.");

            await using var src = new FileStream(chunkPath, FileMode.Open, FileAccess.Read, FileShare.Read, 1024 * 1024, FileOptions.Asynchronous);
            var buffer = new byte[1024 * 1024];
            int read;
            while ((read = await src.ReadAsync(buffer.AsMemory(0, buffer.Length), ct)) > 0)
            {
                await dest.WriteAsync(buffer.AsMemory(0, read), ct);
                sha.AppendData(buffer.AsSpan(0, read));
            }
        }

        await dest.FlushAsync(ct);
        var hash = Convert.ToHexString(sha.GetHashAndReset()).ToLowerInvariant();
        return (finalPath, dest.Length, hash);
    }

    public void CleanupSession(string folder, int sessionId)
    {
        var path = Path.Combine(GetClientPath(folder), ".sessions", sessionId.ToString("D8"));
        try
        {
            if (Directory.Exists(path))
                Directory.Delete(path, true);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to cleanup session {SessionId}", sessionId);
        }
    }

    public void DeleteFile(string storagePath)
    {
        try
        {
            if (File.Exists(storagePath))
                File.Delete(storagePath);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to delete {Path}", storagePath);
        }
    }

    public Stream OpenRead(string storagePath) =>
        new FileStream(storagePath, FileMode.Open, FileAccess.Read, FileShare.Read, 1024 * 1024, FileOptions.Asynchronous);

    public long GetUsedBytes()
    {
        if (!Directory.Exists(_root)) return 0;
        return new DirectoryInfo(_root)
            .EnumerateFiles("*", SearchOption.AllDirectories)
            .Where(f => !f.DirectoryName!.Contains($"{Path.DirectorySeparatorChar}.sessions{Path.DirectorySeparatorChar}") &&
                        !f.FullName.Contains($"{Path.DirectorySeparatorChar}.sessions{Path.DirectorySeparatorChar}"))
            .Sum(f => f.Length);
    }

    public long GetClientUsedBytes(string folder)
    {
        var path = GetClientPath(folder);
        if (!Directory.Exists(path)) return 0;
        return new DirectoryInfo(path)
            .EnumerateFiles("*", SearchOption.AllDirectories)
            .Where(f => !f.FullName.Contains($"{Path.DirectorySeparatorChar}.sessions{Path.DirectorySeparatorChar}"))
            .Sum(f => f.Length);
    }

    public static string SanitizeFolder(string folder)
    {
        var cleaned = Path.GetFileName(folder.Replace('\\', '/').Trim('/'));
        if (string.IsNullOrWhiteSpace(cleaned) || cleaned.Contains(".."))
            throw new InvalidOperationException("Invalid storage folder.");
        return cleaned;
    }

    public static string SanitizeFileName(string name)
    {
        var invalid = Path.GetInvalidFileNameChars();
        var cleaned = new string(name.Select(c => invalid.Contains(c) ? '_' : c).ToArray());
        return string.IsNullOrWhiteSpace(cleaned) ? "backup" : cleaned.Trim();
    }

    public static async Task<string> HashFileAsync(string path, CancellationToken ct)
    {
        await using var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read, 1024 * 1024, FileOptions.Asynchronous);
        using var sha = SHA256.Create();
        var hash = await sha.ComputeHashAsync(fs, ct);
        return Convert.ToHexString(hash).ToLowerInvariant();
    }

    public static string HashBytes(byte[] data)
    {
        var hash = SHA256.HashData(data);
        return Convert.ToHexString(hash).ToLowerInvariant();
    }
}
