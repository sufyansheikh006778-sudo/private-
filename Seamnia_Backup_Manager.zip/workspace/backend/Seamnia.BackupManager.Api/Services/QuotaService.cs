using Microsoft.EntityFrameworkCore;
using Seamnia.BackupManager.Api.Data;
using Seamnia.BackupManager.Api.Models;

namespace Seamnia.BackupManager.Api.Services;

public class QuotaService
{
    private readonly AppDbContext _db;

    public QuotaService(AppDbContext db)
    {
        _db = db;
    }

    public async Task<(bool Allowed, string Message, DateTimeOffset NextAvailable, int SuccessfulThisWeek)> CanUploadAsync(int clientId, CancellationToken ct)
    {
        var (start, end) = PktTime.CurrentWeek();
        var successful = await _db.Backups.CountAsync(b =>
            b.ClientId == clientId &&
            b.UploadStatus == BackupStatuses.Success &&
            b.CompletedAt >= start &&
            b.CompletedAt < end, ct);

        var client = await _db.Clients.FindAsync(new object[] { clientId }, ct);
        var extra = client?.ExtraUploadCredits ?? 0;
        var next = PktTime.NextMonday();

        if (successful < 1)
            return (true, "Upload allowed.", next, successful);

        if (extra > 0)
            return (true, "Upload allowed using administrator override credit.", next, successful);

        return (false, $"Weekly upload limit reached. Next available upload: {next:dddd, dd MMM yyyy} 00:00 PKT.", next, successful);
    }

    public async Task ConsumeOverrideIfNeededAsync(int clientId, bool usedOverride)
    {
        if (!usedOverride) return;
        var client = await _db.Clients.FindAsync(clientId);
        if (client == null) return;
        if (client.ExtraUploadCredits > 0)
            client.ExtraUploadCredits -= 1;
        await _db.SaveChangesAsync();
    }
}
