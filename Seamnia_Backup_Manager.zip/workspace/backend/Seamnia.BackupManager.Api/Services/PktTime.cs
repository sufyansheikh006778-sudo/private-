namespace Seamnia.BackupManager.Api.Services;

public static class PktTime
{
    public static readonly TimeSpan Offset = TimeSpan.FromHours(5);

    public static DateTimeOffset Now => DateTimeOffset.UtcNow.ToOffset(Offset);

    public static DateTimeOffset ToPkt(DateTimeOffset value) => value.ToOffset(Offset);

    public static (DateTimeOffset Start, DateTimeOffset End) CurrentWeek()
    {
        var now = Now;
        var daysFromMonday = ((int)now.DayOfWeek + 6) % 7;
        var startLocal = now.Date.AddDays(-daysFromMonday);
        var start = new DateTimeOffset(startLocal, Offset);
        return (start, start.AddDays(7));
    }

    public static DateTimeOffset NextMonday()
    {
        var (_, end) = CurrentWeek();
        return end;
    }
}
