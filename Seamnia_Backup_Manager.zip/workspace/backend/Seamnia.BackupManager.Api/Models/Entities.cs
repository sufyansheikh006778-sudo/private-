namespace Seamnia.BackupManager.Api.Models;

public static class UserRoles
{
    public const string SuperAdmin = "SuperAdmin";
    public const string Admin = "Admin";
    public const string Client = "Client";
}

public static class BackupStatuses
{
    public const string Pending = "Pending";
    public const string Uploading = "Uploading";
    public const string Success = "Success";
    public const string Failed = "Failed";
    public const string Cancelled = "Cancelled";
}

public static class VerificationStatuses
{
    public const string PendingVerification = "Pending Verification";
    public const string Verified = "Verified";
    public const string VerificationFailed = "Verification Failed";
}

public static class SessionStatuses
{
    public const string Active = "Active";
    public const string Completed = "Completed";
    public const string Failed = "Failed";
    public const string Cancelled = "Cancelled";
}

public class User
{
    public int Id { get; set; }
    public string Username { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;
    public string FullName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Role { get; set; } = UserRoles.Client;
    public bool IsActive { get; set; } = true;
    public int? ClientId { get; set; }
    public Client? Client { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset? LastLoginAt { get; set; }
    public bool MustChangePassword { get; set; }
}

public class Client
{
    public int Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string CompanyName { get; set; } = string.Empty;
    public string ContactName { get; set; } = string.Empty;
    public string ContactEmail { get; set; } = string.Empty;
    public string ContactPhone { get; set; } = string.Empty;
    public string StorageFolder { get; set; } = string.Empty;
    public bool IsActive { get; set; } = true;
    public int ExtraUploadCredits { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset? DeactivatedAt { get; set; }
    public ICollection<User> Users { get; set; } = new List<User>();
    public ICollection<Backup> Backups { get; set; } = new List<Backup>();
}

public class Backup
{
    public int Id { get; set; }
    public int ClientId { get; set; }
    public Client Client { get; set; } = null!;
    public int? UploadedByUserId { get; set; }
    public User? UploadedByUser { get; set; }
    public string OriginalFileName { get; set; } = string.Empty;
    public string StoredFileName { get; set; } = string.Empty;
    public string StoragePath { get; set; } = string.Empty;
    public long FileSizeBytes { get; set; }
    public string Sha256Hash { get; set; } = string.Empty;
    public string? Remarks { get; set; }
    public string UploadStatus { get; set; } = BackupStatuses.Pending;
    public string VerificationStatus { get; set; } = VerificationStatuses.PendingVerification;
    public string? VerificationMessage { get; set; }
    public DateTimeOffset? VerifiedAt { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset? CompletedAt { get; set; }
    public bool UsedQuotaOverride { get; set; }
    public int? UploadSessionId { get; set; }
}

public class UploadSession
{
    public int Id { get; set; }
    public int ClientId { get; set; }
    public Client Client { get; set; } = null!;
    public int UserId { get; set; }
    public User User { get; set; } = null!;
    public string OriginalFileName { get; set; } = string.Empty;
    public long FileSizeBytes { get; set; }
    public int ChunkSizeBytes { get; set; }
    public int TotalChunks { get; set; }
    public string Status { get; set; } = SessionStatuses.Active;
    public string? Remarks { get; set; }
    public string TempDirectory { get; set; } = string.Empty;
    public string? ErrorMessage { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset ExpiresAt { get; set; }
    public DateTimeOffset? CompletedAt { get; set; }
    public ICollection<UploadChunk> Chunks { get; set; } = new List<UploadChunk>();
}

public class UploadChunk
{
    public int Id { get; set; }
    public int UploadSessionId { get; set; }
    public UploadSession UploadSession { get; set; } = null!;
    public int ChunkIndex { get; set; }
    public long ChunkSizeBytes { get; set; }
    public string Sha256Hash { get; set; } = string.Empty;
    public DateTimeOffset ReceivedAt { get; set; }
}

public class AuditLog
{
    public int Id { get; set; }
    public int? UserId { get; set; }
    public string Username { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
    public string Action { get; set; } = string.Empty;
    public string EntityType { get; set; } = string.Empty;
    public string? EntityId { get; set; }
    public string Details { get; set; } = string.Empty;
    public string IpAddress { get; set; } = string.Empty;
    public DateTimeOffset CreatedAt { get; set; }
}

public class SystemSetting
{
    public int Id { get; set; }
    public string Key { get; set; } = string.Empty;
    public string Value { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public DateTimeOffset UpdatedAt { get; set; }
}
