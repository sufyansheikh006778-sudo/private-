namespace Seamnia.BackupManager.Api.Models;

public record LoginRequest(string Username, string Password);
public record ChangePasswordRequest(string CurrentPassword, string NewPassword);
public record LoginResponse(string Token, string Role, string Username, string FullName, int UserId, int? ClientId, string? CompanyName, bool MustChangePassword);

public record CreateAdminRequest(string Username, string Password, string FullName, string Email);
public record UpdateUserRequest(string? FullName, string? Email, bool? IsActive, string? Password);

public record CreateClientRequest(
    string CompanyName,
    string ContactName,
    string ContactEmail,
    string ContactPhone,
    string? Username,
    string? Password);

public record UpdateClientRequest(
    string? CompanyName,
    string? ContactName,
    string? ContactEmail,
    string? ContactPhone,
    bool? IsActive);

public record ResetPasswordRequest(string NewPassword);
public record OverrideQuotaRequest(int ExtraCredits, string Reason);

public record StartUploadRequest(string FileName, long FileSizeBytes, string? Remarks, int? ChunkSizeBytes);
public record StartUploadResponse(
    int SessionId,
    int ChunkSizeBytes,
    int TotalChunks,
    List<int> ReceivedChunks,
    bool UsedOverride,
    DateTimeOffset NextAvailableUpload);

public record CompleteUploadRequest(string? ClientSha256);
public record SettingUpdateRequest(string Key, string Value);

public class UserDto
{
    public int Id { get; set; }
    public string Username { get; set; } = "";
    public string FullName { get; set; } = "";
    public string Email { get; set; } = "";
    public string Role { get; set; } = "";
    public bool IsActive { get; set; }
    public int? ClientId { get; set; }
    public string? CompanyName { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset? LastLoginAt { get; set; }
}

public class ClientDto
{
    public int Id { get; set; }
    public string Code { get; set; } = "";
    public string CompanyName { get; set; } = "";
    public string ContactName { get; set; } = "";
    public string ContactEmail { get; set; } = "";
    public string ContactPhone { get; set; } = "";
    public string StorageFolder { get; set; } = "";
    public bool IsActive { get; set; }
    public int ExtraUploadCredits { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
    public int BackupCount { get; set; }
    public long StorageUsedBytes { get; set; }
    public DateTimeOffset? LastUploadAt { get; set; }
    public string? Username { get; set; }
}

public class BackupDto
{
    public int Id { get; set; }
    public int ClientId { get; set; }
    public string ClientName { get; set; } = "";
    public string ClientCode { get; set; } = "";
    public string OriginalFileName { get; set; } = "";
    public long FileSizeBytes { get; set; }
    public string Sha256Hash { get; set; } = "";
    public string? Remarks { get; set; }
    public string UploadStatus { get; set; } = "";
    public string VerificationStatus { get; set; } = "";
    public string? VerificationMessage { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset? CompletedAt { get; set; }
    public bool UsedQuotaOverride { get; set; }
}

public class SessionDto
{
    public int Id { get; set; }
    public int ClientId { get; set; }
    public string ClientName { get; set; } = "";
    public string OriginalFileName { get; set; } = "";
    public long FileSizeBytes { get; set; }
    public int ChunkSizeBytes { get; set; }
    public int TotalChunks { get; set; }
    public int ReceivedChunks { get; set; }
    public string Status { get; set; } = "";
    public string? Remarks { get; set; }
    public string? ErrorMessage { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset ExpiresAt { get; set; }
}

public class DashboardStatsDto
{
    public int TotalClients { get; set; }
    public int ActiveClients { get; set; }
    public int TotalBackups { get; set; }
    public long StorageUsedBytes { get; set; }
    public long AvailableStorageBytes { get; set; }
    public int WeeklyUploads { get; set; }
    public int PendingBackups { get; set; }
    public int FailedUploads { get; set; }
    public List<BackupDto> LatestUploads { get; set; } = new();
}

public class ClientDashboardDto
{
    public string CompanyName { get; set; } = "";
    public string FullName { get; set; } = "";
    public int TotalBackups { get; set; }
    public DateTimeOffset? LastUploadAt { get; set; }
    public string? LatestStatus { get; set; }
    public DateTimeOffset NextAvailableUpload { get; set; }
    public bool CanUpload { get; set; }
    public string QuotaMessage { get; set; } = "";
    public int ExtraUploadCredits { get; set; }
    public long StorageUsedBytes { get; set; }
}

public class PagedResult<T>
{
    public List<T> Items { get; set; } = new();
    public int Total { get; set; }
    public int Page { get; set; }
    public int PageSize { get; set; }
}

public class AuditLogDto
{
    public int Id { get; set; }
    public string Username { get; set; } = "";
    public string Role { get; set; } = "";
    public string Action { get; set; } = "";
    public string EntityType { get; set; } = "";
    public string? EntityId { get; set; }
    public string Details { get; set; } = "";
    public string IpAddress { get; set; } = "";
    public DateTimeOffset CreatedAt { get; set; }
}

public class SettingDto
{
    public string Key { get; set; } = "";
    public string Value { get; set; } = "";
    public string Description { get; set; } = "";
    public DateTimeOffset UpdatedAt { get; set; }
}

public class ReportDto
{
    public int TotalClients { get; set; }
    public int ActiveClients { get; set; }
    public int InactiveClients { get; set; }
    public int SuccessfulBackups { get; set; }
    public int FailedBackups { get; set; }
    public int PendingVerification { get; set; }
    public int Verified { get; set; }
    public int VerificationFailed { get; set; }
    public long StorageUsedBytes { get; set; }
    public List<ClientStorageRow> TopClients { get; set; } = new();
    public List<WeeklyCount> WeeklyTrend { get; set; } = new();
}

public class ClientStorageRow
{
    public string CompanyName { get; set; } = "";
    public string Code { get; set; } = "";
    public int BackupCount { get; set; }
    public long StorageUsedBytes { get; set; }
}

public class WeeklyCount
{
    public string WeekStart { get; set; } = "";
    public int Count { get; set; }
}

public class GeneratedCredentials
{
    public string Username { get; set; } = "";
    public string Password { get; set; } = "";
}
