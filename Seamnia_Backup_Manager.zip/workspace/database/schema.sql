-- Seamnia Backup Manager — Microsoft SQL Server schema
-- Target: SQL Server 2019+
-- Files are stored on disk under SeamniaBackupStorage, not in these tables.

IF DB_ID(N'SeamniaBackupManager') IS NULL
BEGIN
    CREATE DATABASE SeamniaBackupManager;
END
GO
USE SeamniaBackupManager;
GO

IF OBJECT_ID(N'dbo.UploadChunks', N'U') IS NOT NULL DROP TABLE dbo.UploadChunks;
IF OBJECT_ID(N'dbo.UploadSessions', N'U') IS NOT NULL DROP TABLE dbo.UploadSessions;
IF OBJECT_ID(N'dbo.Backups', N'U') IS NOT NULL DROP TABLE dbo.Backups;
IF OBJECT_ID(N'dbo.AuditLogs', N'U') IS NOT NULL DROP TABLE dbo.AuditLogs;
IF OBJECT_ID(N'dbo.Users', N'U') IS NOT NULL DROP TABLE dbo.Users;
IF OBJECT_ID(N'dbo.Clients', N'U') IS NOT NULL DROP TABLE dbo.Clients;
IF OBJECT_ID(N'dbo.SystemSettings', N'U') IS NOT NULL DROP TABLE dbo.SystemSettings;
GO

CREATE TABLE dbo.Clients (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Code NVARCHAR(32) NOT NULL UNIQUE,
    CompanyName NVARCHAR(200) NOT NULL,
    ContactName NVARCHAR(160) NOT NULL DEFAULT N'',
    ContactEmail NVARCHAR(160) NOT NULL DEFAULT N'',
    ContactPhone NVARCHAR(64) NOT NULL DEFAULT N'',
    StorageFolder NVARCHAR(80) NOT NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    ExtraUploadCredits INT NOT NULL DEFAULT 0,
    CreatedAt DATETIMEOFFSET NOT NULL,
    DeactivatedAt DATETIMEOFFSET NULL
);

CREATE TABLE dbo.Users (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Username NVARCHAR(80) NOT NULL UNIQUE,
    PasswordHash NVARCHAR(200) NOT NULL,
    FullName NVARCHAR(160) NOT NULL DEFAULT N'',
    Email NVARCHAR(160) NOT NULL DEFAULT N'',
    Role NVARCHAR(32) NOT NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    ClientId INT NULL REFERENCES dbo.Clients(Id) ON DELETE SET NULL,
    CreatedAt DATETIMEOFFSET NOT NULL,
    LastLoginAt DATETIMEOFFSET NULL,
    MustChangePassword BIT NOT NULL DEFAULT 0
);

CREATE TABLE dbo.Backups (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    ClientId INT NOT NULL REFERENCES dbo.Clients(Id),
    UploadedByUserId INT NULL REFERENCES dbo.Users(Id),
    OriginalFileName NVARCHAR(260) NOT NULL,
    StoredFileName NVARCHAR(260) NOT NULL,
    StoragePath NVARCHAR(500) NOT NULL,
    FileSizeBytes BIGINT NOT NULL,
    Sha256Hash NVARCHAR(64) NOT NULL,
    Remarks NVARCHAR(1000) NULL,
    UploadStatus NVARCHAR(32) NOT NULL,
    VerificationStatus NVARCHAR(64) NOT NULL,
    VerificationMessage NVARCHAR(1000) NULL,
    VerifiedAt DATETIMEOFFSET NULL,
    CreatedAt DATETIMEOFFSET NOT NULL,
    CompletedAt DATETIMEOFFSET NULL,
    UsedQuotaOverride BIT NOT NULL DEFAULT 0,
    UploadSessionId INT NULL
);
CREATE INDEX IX_Backups_Client_Created ON dbo.Backups (ClientId, CreatedAt);
CREATE INDEX IX_Backups_Sha256 ON dbo.Backups (Sha256Hash);

CREATE TABLE dbo.UploadSessions (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    ClientId INT NOT NULL REFERENCES dbo.Clients(Id),
    UserId INT NOT NULL REFERENCES dbo.Users(Id),
    OriginalFileName NVARCHAR(260) NOT NULL,
    FileSizeBytes BIGINT NOT NULL,
    ChunkSizeBytes INT NOT NULL,
    TotalChunks INT NOT NULL,
    Status NVARCHAR(32) NOT NULL,
    Remarks NVARCHAR(1000) NULL,
    TempDirectory NVARCHAR(500) NOT NULL DEFAULT N'',
    ErrorMessage NVARCHAR(1000) NULL,
    CreatedAt DATETIMEOFFSET NOT NULL,
    ExpiresAt DATETIMEOFFSET NOT NULL,
    CompletedAt DATETIMEOFFSET NULL
);
CREATE INDEX IX_UploadSessions_Client_Status ON dbo.UploadSessions (ClientId, Status);

CREATE TABLE dbo.UploadChunks (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    UploadSessionId INT NOT NULL REFERENCES dbo.UploadSessions(Id) ON DELETE CASCADE,
    ChunkIndex INT NOT NULL,
    ChunkSizeBytes BIGINT NOT NULL,
    Sha256Hash NVARCHAR(64) NOT NULL DEFAULT N'',
    ReceivedAt DATETIMEOFFSET NOT NULL,
    CONSTRAINT UQ_UploadChunks UNIQUE (UploadSessionId, ChunkIndex)
);

CREATE TABLE dbo.AuditLogs (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    UserId INT NULL,
    Username NVARCHAR(80) NOT NULL,
    Role NVARCHAR(32) NOT NULL,
    Action NVARCHAR(80) NOT NULL,
    EntityType NVARCHAR(80) NOT NULL,
    EntityId NVARCHAR(64) NULL,
    Details NVARCHAR(2000) NOT NULL,
    IpAddress NVARCHAR(64) NOT NULL DEFAULT N'',
    CreatedAt DATETIMEOFFSET NOT NULL
);
CREATE INDEX IX_AuditLogs_Created ON dbo.AuditLogs (CreatedAt);

CREATE TABLE dbo.SystemSettings (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    [Key] NVARCHAR(80) NOT NULL UNIQUE,
    Value NVARCHAR(500) NOT NULL,
    Description NVARCHAR(400) NOT NULL DEFAULT N'',
    UpdatedAt DATETIMEOFFSET NOT NULL
);
GO
