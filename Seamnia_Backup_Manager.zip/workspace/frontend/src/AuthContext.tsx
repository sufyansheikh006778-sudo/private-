import { createContext, useContext, useMemo, useState, type ReactNode } from 'react'
import { AuthApi } from './api'
import type { AuthUser } from './types'

interface AuthState {
  user: AuthUser | null
  login: (username: string, password: string) => Promise<AuthUser>
  logout: () => void
  refresh: () => Promise<void>
}

const Ctx = createContext<AuthState | null>(null)

function load(): AuthUser | null {
  const raw = localStorage.getItem('seamnia_auth')
  if (!raw) return null
  try {
    return JSON.parse(raw) as AuthUser
  } catch {
    return null
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(load)

  const value = useMemo<AuthState>(
    () => ({
      user,
      login: async (username, password) => {
        const u = await AuthApi.login(username, password)
        localStorage.setItem('seamnia_auth', JSON.stringify(u))
        setUser(u)
        return u
      },
      logout: () => {
        localStorage.removeItem('seamnia_auth')
        setUser(null)
      },
      refresh: async () => {
        const u = await AuthApi.me()
        localStorage.setItem('seamnia_auth', JSON.stringify(u))
        setUser(u)
      },
    }),
    [user],
  )

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}

export function useAuth() {
  const ctx = useContext(Ctx)
  if (!ctx) throw new Error('AuthProvider missing')
  return ctx
}
