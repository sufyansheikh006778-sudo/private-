import { NavLink, Outlet, useNavigate } from 'react-router-dom'
import { useAuth } from '../AuthContext'

const adminNav = [
  { to: '/admin', label: 'Dashboard', end: true },
  { to: '/admin/clients', label: 'Clients' },
  { to: '/admin/users', label: 'Users', role: 'SuperAdmin' },
  { to: '/admin/backups', label: 'Backups' },
  { to: '/admin/uploads', label: 'Upload Monitoring' },
  { to: '/admin/storage', label: 'Storage Management' },
  { to: '/admin/audit', label: 'Audit Logs', role: 'SuperAdmin' },
  { to: '/admin/reports', label: 'Reports' },
  { to: '/admin/settings', label: 'Settings', role: 'SuperAdmin' },
]

const clientNav = [
  { to: '/client', label: 'Dashboard', end: true },
  { to: '/client/upload', label: 'Upload Backup' },
  { to: '/client/backups', label: 'My Backups' },
  { to: '/client/account', label: 'Account Details' },
]

export default function Layout() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const isClient = user?.role === 'Client'
  const nav = isClient ? clientNav : adminNav.filter((n) => !('role' in n) || n.role === user?.role)

  return (
    <div className="min-h-screen bg-[#050d1a] text-slate-100 flex">
      <aside className="w-64 shrink-0 bg-[#071428] border-r border-[#1a3358] flex flex-col">
        <div className="px-5 py-6 border-b border-[#1a3358]">
          <div className="text-[10px] tracking-[0.25em] text-[#c9a227] uppercase">Seamnia Software House</div>
          <div className="mt-1 text-lg font-semibold text-white leading-tight">Backup Manager</div>
        </div>
        <nav className="flex-1 py-4 px-3 space-y-1">
          {nav.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={'end' in item ? Boolean(item.end) : false}
              className={({ isActive }) =>
                `block rounded-md px-3 py-2 text-sm ${isActive ? 'bg-[#1a3358] text-[#e4c56a]' : 'text-slate-300 hover:bg-[#122544]'}`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>
        <div className="p-4 border-t border-[#1a3358] text-xs text-slate-400">
          <div className="text-slate-200 font-medium">{user?.fullName}</div>
          <div className="text-[#c9a227]">{user?.role}</div>
          <button
            className="mt-3 text-[#e4c56a] hover:underline"
            onClick={() => {
              logout()
              navigate('/login')
            }}
          >
            Sign out
          </button>
        </div>
      </aside>
      <main className="flex-1 min-w-0">
        <header className="h-14 border-b border-[#1a3358] bg-[#071428]/80 backdrop-blur flex items-center justify-between px-6">
          <div className="text-sm text-slate-400">Pakistan Standard Time (PKT, UTC+5)</div>
          <div className="text-sm text-slate-300">{user?.companyName || 'Seamnia Software House'}</div>
        </header>
        <div className="p-6">
          <Outlet />
        </div>
      </main>
    </div>
  )
}
