import type { ReactNode } from 'react'

export function Card({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <div className={`rounded-xl border border-[#1a3358] bg-[#0b1c36] ${className}`}>{children}</div>
}

export function Stat({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <Card className="p-4">
      <div className="text-xs uppercase tracking-wider text-slate-400">{label}</div>
      <div className="mt-1 text-2xl font-semibold text-white">{value}</div>
      {hint ? <div className="mt-1 text-xs text-[#c9a227]">{hint}</div> : null}
    </Card>
  )
}

export function Button({
  children,
  onClick,
  type = 'button',
  variant = 'primary',
  disabled,
  className = '',
}: {
  children: ReactNode
  onClick?: () => void
  type?: 'button' | 'submit'
  variant?: 'primary' | 'ghost' | 'danger'
  disabled?: boolean
  className?: string
}) {
  const styles =
    variant === 'primary'
      ? 'bg-[#c9a227] text-[#071428] hover:bg-[#e4c56a]'
      : variant === 'danger'
        ? 'bg-red-900/60 text-red-100 hover:bg-red-800'
        : 'border border-[#1a3358] text-slate-200 hover:bg-[#122544]'
  return (
    <button
      type={type}
      disabled={disabled}
      onClick={onClick}
      className={`rounded-md px-4 py-2 text-sm font-medium disabled:opacity-50 ${styles} ${className}`}
    >
      {children}
    </button>
  )
}

export function Input(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className={`w-full rounded-md border border-[#1a3358] bg-[#071428] px-3 py-2 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:ring-1 focus:ring-[#c9a227] ${props.className ?? ''}`}
    />
  )
}

export function Select(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      {...props}
      className={`w-full rounded-md border border-[#1a3358] bg-[#071428] px-3 py-2 text-sm text-white focus:outline-none focus:ring-1 focus:ring-[#c9a227] ${props.className ?? ''}`}
    />
  )
}

export function TextArea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      {...props}
      className={`w-full rounded-md border border-[#1a3358] bg-[#071428] px-3 py-2 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:ring-1 focus:ring-[#c9a227] ${props.className ?? ''}`}
    />
  )
}

export function Badge({ children, tone = 'gold' }: { children: ReactNode; tone?: 'gold' | 'green' | 'red' | 'slate' | 'blue' }) {
  const map = {
    gold: 'bg-[#c9a227]/15 text-[#e4c56a]',
    green: 'bg-emerald-500/15 text-emerald-300',
    red: 'bg-red-500/15 text-red-300',
    slate: 'bg-slate-500/20 text-slate-300',
    blue: 'bg-sky-500/15 text-sky-300',
  }
  return <span className={`inline-flex rounded-full px-2 py-0.5 text-xs ${map[tone]}`}>{children}</span>
}

export function statusTone(status: string) {
  if (status === 'Success' || status === 'Verified' || status === 'Completed' || status === 'Active') return 'green' as const
  if (status.includes('Fail') || status === 'Cancelled') return 'red' as const
  if (status.includes('Pending') || status === 'Uploading') return 'gold' as const
  return 'slate' as const
}

export function Alert({ children, kind = 'info' }: { children: ReactNode; kind?: 'info' | 'ok' | 'err' }) {
  const cls = kind === 'ok' ? 'border-emerald-700 bg-emerald-950/40 text-emerald-200' : kind === 'err' ? 'border-red-800 bg-red-950/40 text-red-200' : 'border-[#1a3358] bg-[#122544] text-slate-200'
  return <div className={`rounded-md border px-3 py-2 text-sm ${cls}`}>{children}</div>
}

export function PageTitle({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="mb-6">
      <h1 className="text-2xl font-semibold text-white">{title}</h1>
      {subtitle ? <p className="mt-1 text-sm text-slate-400">{subtitle}</p> : null}
    </div>
  )
}
