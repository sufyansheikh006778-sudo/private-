import type { ReactNode } from 'react'
import { Navigate, Route, Routes } from 'react-router-dom'
import { useAuth } from './AuthContext'
import Layout from './components/Layout'
import Login from './pages/Login'
import AdminDashboard from './pages/admin/AdminDashboard'
import ClientsPage from './pages/admin/ClientsPage'
import UsersPage from './pages/admin/UsersPage'
import BackupsPage from './pages/admin/BackupsPage'
import UploadsPage from './pages/admin/UploadsPage'
import StoragePage from './pages/admin/StoragePage'
import AuditPage from './pages/admin/AuditPage'
import ReportsPage from './pages/admin/ReportsPage'
import SettingsPage from './pages/admin/SettingsPage'
import ClientDashboard from './pages/client/ClientDashboard'
import UploadPage from './pages/client/UploadPage'
import MyBackupsPage from './pages/client/MyBackupsPage'
import AccountPage from './pages/client/AccountPage'
import type { Role } from './types'

function Guard({ roles, children }: { roles: Role[]; children: ReactNode }) {
  const { user } = useAuth()
  if (!user) return <Navigate to="/login" replace />
  if (!roles.includes(user.role)) {
    return <Navigate to={user.role === 'Client' ? '/client' : '/admin'} replace />
  }
  return <>{children}</>
}

export default function App() {
  const { user } = useAuth()
  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to={user.role === 'Client' ? '/client' : '/admin'} replace /> : <Login />} />
      <Route
        element={
          <Guard roles={['SuperAdmin', 'Admin', 'Client']}>
            <Layout />
          </Guard>
        }
      >
        <Route
          path="/admin"
          element={<Guard roles={['SuperAdmin', 'Admin']}><AdminDashboard /></Guard>}
        />
        <Route path="/admin/clients" element={<Guard roles={['SuperAdmin', 'Admin']}><ClientsPage /></Guard>} />
        <Route path="/admin/users" element={<Guard roles={['SuperAdmin']}><UsersPage /></Guard>} />
        <Route path="/admin/backups" element={<Guard roles={['SuperAdmin', 'Admin']}><BackupsPage /></Guard>} />
        <Route path="/admin/uploads" element={<Guard roles={['SuperAdmin', 'Admin']}><UploadsPage /></Guard>} />
        <Route path="/admin/storage" element={<Guard roles={['SuperAdmin', 'Admin']}><StoragePage /></Guard>} />
        <Route path="/admin/audit" element={<Guard roles={['SuperAdmin']}><AuditPage /></Guard>} />
        <Route path="/admin/reports" element={<Guard roles={['SuperAdmin', 'Admin']}><ReportsPage /></Guard>} />
        <Route path="/admin/settings" element={<Guard roles={['SuperAdmin']}><SettingsPage /></Guard>} />
        <Route path="/client" element={<Guard roles={['Client']}><ClientDashboard /></Guard>} />
        <Route path="/client/upload" element={<Guard roles={['Client']}><UploadPage /></Guard>} />
        <Route path="/client/backups" element={<Guard roles={['Client']}><MyBackupsPage /></Guard>} />
        <Route path="/client/account" element={<Guard roles={['Client']}><AccountPage /></Guard>} />
      </Route>
      <Route path="*" element={<Navigate to={user ? (user.role === 'Client' ? '/client' : '/admin') : '/login'} replace />} />
    </Routes>
  )
}
