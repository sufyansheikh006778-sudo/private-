import axios from 'axios'
import type {
  AuditLogDto,
  AuthUser,
  BackupDto,
  ClientDashboard,
  ClientDto,
  DashboardStats,
  Paged,
  ReportDto,
  SessionDto,
  SettingDto,
  UserDto,
} from './types'

const api = axios.create({ baseURL: '/api' })

api.interceptors.request.use((config) => {
  const raw = localStorage.getItem('seamnia_auth')
  if (raw) {
    const auth = JSON.parse(raw) as AuthUser
    config.headers.Authorization = `Bearer ${auth.token}`
  }
  return config
})

api.interceptors.response.use(
  (r) => r,
  (err) => {
    if (err.response?.status === 401 && !window.location.pathname.startsWith('/login')) {
      localStorage.removeItem('seamnia_auth')
      window.location.href = '/login'
    }
    return Promise.reject(err)
  },
)

export function errorMessage(err: unknown, fallback = 'Request failed.') {
  if (axios.isAxiosError(err)) {
    const data = err.response?.data as { message?: string } | undefined
    return data?.message || err.message || fallback
  }
  return fallback
}

export const AuthApi = {
  login: (username: string, password: string) =>
    api.post<AuthUser>('/auth/login', { username, password }).then((r) => r.data),
  me: () => api.get<AuthUser>('/auth/me').then((r) => r.data),
  changePassword: (currentPassword: string, newPassword: string) =>
    api.post('/auth/change-password', { currentPassword, newPassword }),
}

export const ClientsApi = {
  list: (params: Record<string, unknown>) =>
    api.get<Paged<ClientDto>>('/clients', { params }).then((r) => r.data),
  get: (id: number) => api.get<ClientDto>(`/clients/${id}`).then((r) => r.data),
  create: (body: Record<string, unknown>) =>
    api.post<{ client: ClientDto; credentials: { username: string; password: string } }>('/clients', body).then((r) => r.data),
  update: (id: number, body: Record<string, unknown>) =>
    api.put<ClientDto>(`/clients/${id}`, body).then((r) => r.data),
  resetPassword: (id: number) =>
    api.post<{ username: string; password: string }>(`/clients/${id}/reset-password`, {}).then((r) => r.data),
  overrideQuota: (id: number, extraCredits: number, reason: string) =>
    api.post(`/clients/${id}/override-quota`, { extraCredits, reason }),
}

export const UsersApi = {
  list: (role?: string) => api.get<UserDto[]>('/users', { params: { role } }).then((r) => r.data),
  create: (body: Record<string, string>) => api.post<UserDto>('/users', body).then((r) => r.data),
  update: (id: number, body: Record<string, unknown>) => api.put<UserDto>(`/users/${id}`, body).then((r) => r.data),
}

export const BackupsApi = {
  list: (params: Record<string, unknown>) =>
    api.get<Paged<BackupDto>>('/backups', { params }).then((r) => r.data),
  verify: (id: number) => api.post<BackupDto>(`/backups/${id}/verify`).then((r) => r.data),
  remove: (id: number) => api.delete(`/backups/${id}`),
  downloadUrl: (id: number) => `/api/backups/${id}/download`,
}

export const UploadsApi = {
  start: (fileName: string, fileSizeBytes: number, remarks: string) =>
    api.post<{
      sessionId: number
      chunkSizeBytes: number
      totalChunks: number
      receivedChunks: number[]
      usedOverride: boolean
      nextAvailableUpload: string
    }>('/uploads/start', { fileName, fileSizeBytes, remarks }).then((r) => r.data),
  putChunk: (sessionId: number, index: number, blob: Blob, onUploadProgress: (e: { loaded: number; total?: number }) => void, signal: AbortSignal) =>
    api.put(`/uploads/${sessionId}/chunks/${index}`, blob, {
      headers: { 'Content-Type': 'application/octet-stream' },
      onUploadProgress,
      signal,
      timeout: 0,
    }),
  complete: (sessionId: number) => api.post<BackupDto>(`/uploads/${sessionId}/complete`, {}).then((r) => r.data),
  cancel: (sessionId: number) => api.post(`/uploads/${sessionId}/cancel`),
  get: (sessionId: number) => api.get<SessionDto>(`/uploads/${sessionId}`).then((r) => r.data),
  monitoring: (params: Record<string, unknown>) =>
    api.get<Paged<SessionDto>>('/uploads/monitoring', { params }).then((r) => r.data),
}

export const DashboardApi = {
  admin: () => api.get<DashboardStats>('/dashboard/admin').then((r) => r.data),
  client: () => api.get<ClientDashboard>('/dashboard/client').then((r) => r.data),
  storage: () => api.get('/dashboard/storage').then((r) => r.data),
}

export const AuditApi = {
  list: (params: Record<string, unknown>) =>
    api.get<Paged<AuditLogDto>>('/audit-logs', { params }).then((r) => r.data),
}

export const SettingsApi = {
  list: () => api.get<SettingDto[]>('/settings').then((r) => r.data),
  update: (key: string, value: string) => api.put('/settings', { key, value }),
}

export const ReportsApi = {
  get: () => api.get<ReportDto>('/reports').then((r) => r.data),
}

export async function downloadBackup(id: number, fileName: string, token: string) {
  const res = await fetch(`/api/backups/${id}/download`, {
    headers: { Authorization: `Bearer ${token}` },
  })
  if (!res.ok) {
    const body = await res.json().catch(() => ({ message: 'Download failed.' }))
    throw new Error(body.message || 'Download failed.')
  }
  const blob = await res.blob()
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = fileName
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(url)
}

export default api
