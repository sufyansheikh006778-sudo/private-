export type Role = 'SuperAdmin' | 'Admin' | 'Client'

export interface AuthUser {
  token: string
  role: Role
  username: string
  fullName: string
  userId: number
  clientId: number | null
  companyName: string | null
  mustChangePassword: boolean
}

export interface Paged<T> {
  items: T[]
  total: number
  page: number
  pageSize: number
}

export interface ClientDto {
  id: number
  code: string
  companyName: string
  contactName: string
  contactEmail: string
  contactPhone: string
  storageFolder: string
  isActive: boolean
  extraUploadCredits: number
  createdAt: string
  backupCount: number
  storageUsedBytes: number
  lastUploadAt: string | null
  username: string | null
}

export interface UserDto {
  id: number
  username: string
  fullName: string
  email: string
  role: string
  isActive: boolean
  clientId: number | null
  companyName: string | null
  createdAt: string
  lastLoginAt: string | null
}

export interface BackupDto {
  id: number
  clientId: number
  clientName: string
  clientCode: string
  originalFileName: string
  fileSizeBytes: number
  sha256Hash: string
  remarks: string | null
  uploadStatus: string
  verificationStatus: string
  verificationMessage: string | null
  createdAt: string
  completedAt: string | null
  usedQuotaOverride: boolean
}

export interface SessionDto {
  id: number
  clientId: number
  clientName: string
  originalFileName: string
  fileSizeBytes: number
  chunkSizeBytes: number
  totalChunks: number
  receivedChunks: number
  status: string
  remarks: string | null
  errorMessage: string | null
  createdAt: string
  expiresAt: string
}

export interface DashboardStats {
  totalClients: number
  activeClients: number
  totalBackups: number
  storageUsedBytes: number
  availableStorageBytes: number
  weeklyUploads: number
  pendingBackups: number
  failedUploads: number
  latestUploads: BackupDto[]
}

export interface ClientDashboard {
  companyName: string
  fullName: string
  totalBackups: number
  lastUploadAt: string | null
  latestStatus: string | null
  nextAvailableUpload: string
  canUpload: boolean
  quotaMessage: string
  extraUploadCredits: number
  storageUsedBytes: number
}

export interface AuditLogDto {
  id: number
  username: string
  role: string
  action: string
  entityType: string
  entityId: string | null
  details: string
  ipAddress: string
  createdAt: string
}

export interface SettingDto {
  key: string
  value: string
  description: string
  updatedAt: string
}

export interface ReportDto {
  totalClients: number
  activeClients: number
  inactiveClients: number
  successfulBackups: number
  failedBackups: number
  pendingVerification: number
  verified: number
  verificationFailed: number
  storageUsedBytes: number
  topClients: { companyName: string; code: string; backupCount: number; storageUsedBytes: number }[]
  weeklyTrend: { weekStart: string; count: number }[]
}
