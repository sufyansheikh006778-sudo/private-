import { useEffect, useState } from 'react'
import { BackupsApi, downloadBackup, errorMessage } from '../../api'
import { useAuth } from '../../AuthContext'
import { Alert, Badge, Button, Card, Input, PageTitle, statusTone } from '../../components/ui'
import { formatBytes, formatPkt } from '../../format'
import type { BackupDto } from '../../types'

export default function MyBackupsPage() {
  const { user } = useAuth()
  const [items, setItems] = useState<BackupDto[]>([])
  const [q, setQ] = useState('')
  const [error, setError] = useState('')

  async function load() {
    try {
      const res = await BackupsApi.list({ q, page: 1, pageSize: 50 })
      setItems(res.items)
    } catch (e) {
      setError(errorMessage(e))
    }
  }
  useEffect(() => { void load() }, [])

  return (
    <div>
      <PageTitle title="My Backups" subtitle="Only your company's backup files are listed here." />
      {error ? <Alert kind="err">{error}</Alert> : null}
      <div className="flex gap-3 mb-4">
        <Input placeholder="Search filename or remarks" value={q} onChange={(e) => setQ(e.target.value)} />
        <Button onClick={() => void load()}>Search</Button>
      </div>
      <Card className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-slate-400 text-left">
            <tr>
              <th className="px-4 py-2 font-normal">Filename</th>
              <th className="px-4 py-2 font-normal">Size</th>
              <th className="px-4 py-2 font-normal">Uploaded</th>
              <th className="px-4 py-2 font-normal">Remarks</th>
              <th className="px-4 py-2 font-normal">Status</th>
              <th className="px-4 py-2 font-normal">Verification</th>
              <th className="px-4 py-2 font-normal"></th>
            </tr>
          </thead>
          <tbody>
            {items.map((b) => (
              <tr key={b.id} className="border-t border-[#1a3358]">
                <td className="px-4 py-2">{b.originalFileName}</td>
                <td className="px-4 py-2">{formatBytes(b.fileSizeBytes)}</td>
                <td className="px-4 py-2">{formatPkt(b.completedAt || b.createdAt)}</td>
                <td className="px-4 py-2 text-slate-400">{b.remarks || '—'}</td>
                <td className="px-4 py-2"><Badge tone={statusTone(b.uploadStatus)}>{b.uploadStatus}</Badge></td>
                <td className="px-4 py-2"><Badge tone={statusTone(b.verificationStatus)}>{b.verificationStatus}</Badge></td>
                <td className="px-4 py-2">
                  {b.uploadStatus === 'Success' ? (
                    <button className="text-[#c9a227] text-xs" onClick={async () => {
                      try { await downloadBackup(b.id, b.originalFileName, user!.token) } catch (e) { setError(errorMessage(e)) }
                    }}>Download</button>
                  ) : null}
                </td>
              </tr>
            ))}
            {items.length === 0 ? <tr><td colSpan={7} className="px-4 py-6 text-slate-500">No backups found.</td></tr> : null}
          </tbody>
        </table>
      </Card>
    </div>
  )
}
