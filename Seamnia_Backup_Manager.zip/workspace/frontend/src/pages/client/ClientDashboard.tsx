import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { BackupsApi, DashboardApi, errorMessage } from '../../api'
import { Alert, Badge, Button, Card, PageTitle, Stat, statusTone } from '../../components/ui'
import { formatBytes, formatDate, formatPkt } from '../../format'
import type { BackupDto, ClientDashboard as Dash } from '../../types'

export default function ClientDashboard() {
  const [dash, setDash] = useState<Dash | null>(null)
  const [history, setHistory] = useState<BackupDto[]>([])
  const [error, setError] = useState('')

  useEffect(() => {
    Promise.all([DashboardApi.client(), BackupsApi.list({ page: 1, pageSize: 8 })])
      .then(([d, h]) => {
        setDash(d)
        setHistory(h.items)
      })
      .catch((e) => setError(errorMessage(e)))
  }, [])

  if (error) return <Alert kind="err">{error}</Alert>
  if (!dash) return <p className="text-slate-400">Loading…</p>

  return (
    <div>
      <PageTitle title={`Welcome, ${dash.fullName || dash.companyName}`} subtitle={dash.companyName} />
      <div className="grid md:grid-cols-4 gap-4">
        <Stat label="Total backups" value={String(dash.totalBackups)} />
        <Stat label="Last upload" value={formatDate(dash.lastUploadAt)} />
        <Stat label="Latest status" value={dash.latestStatus || '—'} />
        <Stat label="Next available" value={formatDate(dash.nextAvailableUpload)} hint="Monday 00:00 PKT" />
      </div>
      <Card className="mt-6 p-5">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-white font-medium">Upload Backup</h2>
            <p className="text-sm text-slate-400 mt-1">{dash.quotaMessage}</p>
            {dash.extraUploadCredits > 0 ? <p className="text-xs text-[#c9a227] mt-1">{dash.extraUploadCredits} extra credit(s) granted by administrator.</p> : null}
          </div>
          <Link to="/client/upload">
            <Button disabled={!dash.canUpload}>{dash.canUpload ? 'Upload .BAK' : 'Quota reached'}</Button>
          </Link>
        </div>
      </Card>
      <Card className="mt-6 overflow-x-auto">
        <div className="px-5 py-3 border-b border-[#1a3358] text-sm text-white">Backup history</div>
        <table className="w-full text-sm">
          <thead className="text-slate-400 text-left">
            <tr>
              <th className="px-5 py-2 font-normal">File</th>
              <th className="px-5 py-2 font-normal">Size</th>
              <th className="px-5 py-2 font-normal">Uploaded</th>
              <th className="px-5 py-2 font-normal">Status</th>
              <th className="px-5 py-2 font-normal">Verification</th>
            </tr>
          </thead>
          <tbody>
            {history.length === 0 ? (
              <tr><td colSpan={5} className="px-5 py-6 text-slate-500">No backups uploaded yet.</td></tr>
            ) : history.map((b) => (
              <tr key={b.id} className="border-t border-[#1a3358]">
                <td className="px-5 py-2">{b.originalFileName}</td>
                <td className="px-5 py-2">{formatBytes(b.fileSizeBytes)}</td>
                <td className="px-5 py-2">{formatPkt(b.completedAt || b.createdAt)}</td>
                <td className="px-5 py-2"><Badge tone={statusTone(b.uploadStatus)}>{b.uploadStatus}</Badge></td>
                <td className="px-5 py-2"><Badge tone={statusTone(b.verificationStatus)}>{b.verificationStatus}</Badge></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  )
}
