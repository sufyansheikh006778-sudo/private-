import { useState, type FormEvent } from 'react'
import { AuthApi, errorMessage } from '../../api'
import { useAuth } from '../../AuthContext'
import { Alert, Button, Card, Input, PageTitle } from '../../components/ui'

export default function AccountPage() {
  const { user } = useAuth()
  const [currentPassword, setCurrent] = useState('')
  const [newPassword, setNew] = useState('')
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')

  async function submit(e: FormEvent) {
    e.preventDefault()
    setError('')
    setNotice('')
    try {
      await AuthApi.changePassword(currentPassword, newPassword)
      setNotice('Password updated.')
      setCurrent('')
      setNew('')
    } catch (err) {
      setError(errorMessage(err))
    }
  }

  return (
    <div>
      <PageTitle title="Account Details" />
      <Card className="p-5 max-w-xl">
        <dl className="grid grid-cols-3 gap-2 text-sm">
          <dt className="text-slate-400">Company</dt><dd className="col-span-2">{user?.companyName}</dd>
          <dt className="text-slate-400">Username</dt><dd className="col-span-2">{user?.username}</dd>
          <dt className="text-slate-400">Name</dt><dd className="col-span-2">{user?.fullName}</dd>
          <dt className="text-slate-400">Role</dt><dd className="col-span-2">{user?.role}</dd>
        </dl>
      </Card>
      <Card className="p-5 max-w-xl mt-4">
        <h2 className="text-white mb-3">Change password</h2>
        {error ? <div className="mb-3"><Alert kind="err">{error}</Alert></div> : null}
        {notice ? <div className="mb-3"><Alert kind="ok">{notice}</Alert></div> : null}
        <form onSubmit={submit} className="space-y-3">
          <Input type="password" placeholder="Current password" value={currentPassword} onChange={(e) => setCurrent(e.target.value)} required />
          <Input type="password" placeholder="New password (min 8 characters)" value={newPassword} onChange={(e) => setNew(e.target.value)} required minLength={8} />
          <Button type="submit">Update password</Button>
        </form>
      </Card>
    </div>
  )
}
