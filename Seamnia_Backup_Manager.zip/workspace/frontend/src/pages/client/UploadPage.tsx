import { useEffect, useRef, useState } from 'react'
import { DashboardApi, UploadsApi, errorMessage } from '../../api'
import { Alert, Button, Card, PageTitle, TextArea } from '../../components/ui'
import { formatBytes } from '../../format'
import type { ClientDashboard } from '../../types'

const MAX = 50 * 1024 * 1024 * 1024

export default function UploadPage() {
  const [dash, setDash] = useState<ClientDashboard | null>(null)
  const [file, setFile] = useState<File | null>(null)
  const [remarks, setRemarks] = useState('')
  const [drag, setDrag] = useState(false)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [progress, setProgress] = useState(0)
  const [speed, setSpeed] = useState(0)
  const [status, setStatus] = useState<'idle' | 'uploading' | 'assembling' | 'done'>('idle')
  const abortRef = useRef<AbortController | null>(null)
  const sessionRef = useRef<number | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    DashboardApi.client().then(setDash).catch((e) => setError(errorMessage(e)))
  }, [])

  function pick(f: File | null) {
    setError('')
    setNotice('')
    if (!f) return
    if (!f.name.toLowerCase().endsWith('.bak')) {
      setError('Only .BAK files are accepted.')
      return
    }
    if (f.size > MAX) {
      setError('Maximum file size is 50 GB.')
      return
    }
    setFile(f)
  }

  async function startUpload() {
    if (!file || !dash?.canUpload) return
    setError('')
    setNotice('')
    setStatus('uploading')
    setProgress(0)
    const controller = new AbortController()
    abortRef.current = controller
    try {
      const session = await UploadsApi.start(file.name, file.size, remarks)
      sessionRef.current = session.sessionId
      const chunkSize = session.chunkSizeBytes
      const total = session.totalChunks
      let uploaded = 0
      const t0 = performance.now()
      for (let i = 0; i < total; i++) {
        if (controller.signal.aborted) throw new Error('Upload cancelled.')
        const start = i * chunkSize
        const end = Math.min(file.size, start + chunkSize)
        const blob = file.slice(start, end)
        await UploadsApi.putChunk(session.sessionId, i, blob, (ev) => {
          const loaded = uploaded + (ev.loaded || 0)
          setProgress(Math.min(99, (loaded / file.size) * 100))
          const elapsed = (performance.now() - t0) / 1000
          if (elapsed > 0) setSpeed(loaded / elapsed)
        }, controller.signal)
        uploaded += blob.size
        setProgress((uploaded / file.size) * 100)
        const elapsed = (performance.now() - t0) / 1000
        if (elapsed > 0) setSpeed(uploaded / elapsed)
      }
      setStatus('assembling')
      const backup = await UploadsApi.complete(session.sessionId)
      setStatus('done')
      setNotice(`Upload successful. ${backup.originalFileName} stored (${formatBytes(backup.fileSizeBytes)}). Verification is running.`)
      sessionRef.current = null
      const d = await DashboardApi.client()
      setDash(d)
    } catch (e) {
      if (controller.signal.aborted) {
        setError('Upload cancelled. Failed uploads do not count against the weekly limit.')
      } else {
        setError(errorMessage(e, 'Upload failed.'))
      }
      setStatus('idle')
    }
  }

  async function cancel() {
    abortRef.current?.abort()
    if (sessionRef.current) {
      try { await UploadsApi.cancel(sessionRef.current) } catch { /* ignore */ }
      sessionRef.current = null
    }
    setStatus('idle')
    setProgress(0)
  }

  return (
    <div>
      <PageTitle title="Upload Backup" subtitle="One successful .BAK upload per Monday–Sunday PKT week. Incomplete uploads do not consume the quota." />
      {error ? <div className="mb-4"><Alert kind="err">{error}</Alert></div> : null}
      {notice ? <div className="mb-4"><Alert kind="ok">{notice}</Alert></div> : null}
      {dash && !dash.canUpload ? <div className="mb-4"><Alert>{dash.quotaMessage}</Alert></div> : null}
      <Card className="p-6">
        <div
          className={`border-2 border-dashed rounded-xl p-10 text-center ${drag ? 'border-[#c9a227] bg-[#c9a227]/5' : 'border-[#1a3358]'}`}
          onDragOver={(e) => { e.preventDefault(); setDrag(true) }}
          onDragLeave={() => setDrag(false)}
          onDrop={(e) => {
            e.preventDefault()
            setDrag(false)
            pick(e.dataTransfer.files[0] ?? null)
          }}
        >
          <p className="text-white">Drag and drop your .BAK file here</p>
          <p className="text-sm text-slate-400 mt-1">or</p>
          <Button className="mt-3" variant="ghost" onClick={() => inputRef.current?.click()}>Browse file</Button>
          <input ref={inputRef} type="file" accept=".bak,.BAK" className="hidden" onChange={(e) => pick(e.target.files?.[0] ?? null)} />
          {file ? (
            <p className="mt-4 text-sm text-[#e4c56a]">{file.name} — {formatBytes(file.size)}</p>
          ) : null}
        </div>
        <label className="block mt-4 text-sm text-slate-300">
          Remarks (optional)
          <TextArea className="mt-1" rows={3} value={remarks} onChange={(e) => setRemarks(e.target.value)} placeholder="e.g. Full backup after month-end closing" />
        </label>
        {status === 'uploading' || status === 'assembling' ? (
          <div className="mt-4">
            <div className="h-2 rounded-full bg-[#122544] overflow-hidden">
              <div className="h-full bg-[#c9a227]" style={{ width: `${progress}%` }} />
            </div>
            <div className="mt-2 flex justify-between text-xs text-slate-400">
              <span>{status === 'assembling' ? 'Reassembling and verifying SHA-256…' : `${progress.toFixed(1)}%`}</span>
              <span>{formatBytes(speed)}/s</span>
            </div>
            <Button variant="danger" className="mt-3" onClick={() => void cancel()}>Cancel upload</Button>
          </div>
        ) : (
          <Button className="mt-4" disabled={!file || !dash?.canUpload} onClick={() => void startUpload()}>
            Start upload
          </Button>
        )}
      </Card>
    </div>
  )
}
