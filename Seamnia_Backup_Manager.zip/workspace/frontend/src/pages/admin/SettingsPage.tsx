import { useEffect, useState } from 'react'
import { SettingsApi, errorMessage } from '../../api'
import { Alert, Button, Card, Input, PageTitle } from '../../components/ui'
import { formatPkt } from '../../format'
import type { SettingDto } from '../../types'

export default function SettingsPage() {
  const [items, setItems] = useState<SettingDto[]>([])
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [draft, setDraft] = useState<Record<string, string>>({})

  useEffect(() => {
    SettingsApi.list()
      .then((list) => {
        setItems(list)
        setDraft(Object.fromEntries(list.map((s) => [s.key, s.value])))
      })
      .catch((e) => setError(errorMessage(e)))
  }, [])

  return (
    <div>
      <PageTitle title="System Settings" subtitle="Upload limits and allocated storage. Changes apply immediately." />
      {error ? <Alert kind="err">{error}</Alert> : null}
      {notice ? <div className="mb-3"><Alert kind="ok">{notice}</Alert></div> : null}
      <div className="space-y-4">
        {items.map((s) => (
          <Card key={s.key} className="p-4">
            <div className="flex flex-col md:flex-row md:items-center gap-3">
              <div className="flex-1">
                <div className="text-white">{s.key}</div>
                <div className="text-xs text-slate-400">{s.description}</div>
                <div className="text-[10px] text-slate-500 mt-1">Updated {formatPkt(s.updatedAt)}</div>
              </div>
              <Input className="md:w-80" value={draft[s.key] ?? ''} onChange={(e) => setDraft({ ...draft, [s.key]: e.target.value })} />
              <Button
                onClick={async () => {
                  try {
                    await SettingsApi.update(s.key, draft[s.key])
                    setNotice(`${s.key} saved.`)
                  } catch (e) {
                    setError(errorMessage(e))
                  }
                }}
              >
                Save
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
