import { useEffect, useState } from 'react'
import { BackupsApi, downloadBackup, errorMessage } from '../../api'
import { useAuth } from '../../AuthContext'
import { Alert, Badge, Button, Card, Input, PageTitle, Select, statusTone } from '../../components/ui'
import { formatBytes, formatPkt } from '../../format'
import type { BackupDto } from '../../types'

export default function BackupsPage() {
  const { user } = useAuth()
  const [q, setQ] = useState('')
  const [status, setStatus] = useState('')
  const [verification, setVerification] = useState('')
  const [from, setFrom] = useState('')
  const [to, setTo] = useState('')
  const [items, setItems] = useState<BackupDto[]>([])
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')

  async function load(p = page) {
    try {
      const res = await BackupsApi.list({
        q, status: status || undefined, verification: verification || undefined,
        from: from || undefined, to: to || undefined, page: p, pageSize: 20,
      })
      setItems(res.items)
      setTotal(res.total)
      setPage(p)
    } catch (e) {
      setError(errorMessage(e))
    }
  }
  useEffect(() => { void load(1) }, [])

  return (
    <div>
      <PageTitle title="Backups" subtitle="Search, filter, verify, download and delete client backup files." />
      {error ? <div className="mb-3"><Alert kind="err">{error}</Alert></div> : null}
      {notice ? <div className="mb-3"><Alert kind="ok">{notice}</Alert></div> : null}
      <div className="grid md:grid-cols-6 gap-3 mb-4">
        <Input placeholder="Search file, client, remarks, hash" value={q} onChange={(e) => setQ(e.target.value)} />
        <Select value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">All statuses</option>
          <option>Success</option>
          <option>Failed</option>
          <option>Pending</option>
        </Select>
        <Select value={verification} onChange={(e) => setVerification(e.target.value)}>
          <option value="">All verification</option>
          <option>Pending Verification</option>
          <option>Verified</option>
          <option>Verification Failed</option>
        </Select>
        <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
        <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
        <Button onClick={() => void load(1)}>Apply filters</Button>
      </div>
      <Card className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-slate-400 text-left">
            <tr>
              <th className="px-4 py-2 font-normal">Client</th>
              <th className="px-4 py-2 font-normal">Filename</th>
              <th className="px-4 py-2 font-normal">Size</th>
              <th className="px-4 py-2 font-normal">Uploaded</th>
              <th className="px-4 py-2 font-normal">Remarks</th>
              <th className="px-4 py-2 font-normal">Status</th>
              <th className="px-4 py-2 font-normal">Verification</th>
              <th className="px-4 py-2 font-normal"></th>
            </tr>
          </thead>
          <tbody>
            {items.map((b) => (
              <tr key={b.id} className="border-t border-[#1a3358]">
                <td className="px-4 py-2">{b.clientName}<div className="text-xs text-slate-500">{b.clientCode}</div></td>
                <td className="px-4 py-2">{b.originalFileName}</td>
                <td className="px-4 py-2">{formatBytes(b.fileSizeBytes)}</td>
                <td className="px-4 py-2">{formatPkt(b.completedAt || b.createdAt)}</td>
                <td className="px-4 py-2 text-slate-400 max-w-xs truncate">{b.remarks || '—'}</td>
                <td className="px-4 py-2"><Badge tone={statusTone(b.uploadStatus)}>{b.uploadStatus}</Badge></td>
                <td className="px-4 py-2">
                  <Badge tone={statusTone(b.verificationStatus)}>{b.verificationStatus}</Badge>
                  {b.usedQuotaOverride ? <div className="text-[10px] text-[#c9a227]">override</div> : null}
                </td>
                <td className="px-4 py-2 whitespace-nowrap space-x-2">
                  <button className="text-[#c9a227] text-xs" onClick={async () => {
                    try { await downloadBackup(b.id, b.originalFileName, user!.token) } catch (e) { setError(errorMessage(e)) }
                  }}>Download</button>
                  <button className="text-[#c9a227] text-xs" onClick={async () => {
                    try {
                      const r = await BackupsApi.verify(b.id)
                      setNotice(`${b.originalFileName}: ${r.verificationStatus}`)
                      await load(page)
                    } catch (e) { setError(errorMessage(e)) }
                  }}>Verify</button>
                  {user?.role === 'SuperAdmin' ? (
                    <button className="text-red-300 text-xs" onClick={async () => {
                      if (!window.confirm('Delete this backup file permanently?')) return
                      try {
                        await BackupsApi.remove(b.id)
                        setNotice('Backup deleted.')
                        await load(page)
                      } catch (e) { setError(errorMessage(e)) }
                    }}>Delete</button>
                  ) : null}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
      <div className="mt-3 flex justify-between text-sm text-slate-400">
        <span>{total} records</span>
        <div className="space-x-2">
          <Button variant="ghost" disabled={page <= 1} onClick={() => void load(page - 1)}>Previous</Button>
          <Button variant="ghost" disabled={page * 20 >= total} onClick={() => void load(page + 1)}>Next</Button>
        </div>
      </div>
    </div>
  )
}
