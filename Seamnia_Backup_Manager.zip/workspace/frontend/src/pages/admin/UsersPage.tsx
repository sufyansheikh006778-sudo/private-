import { useEffect, useState, type FormEvent } from 'react'
import { UsersApi, errorMessage } from '../../api'
import { Alert, Badge, Button, Card, Input, PageTitle } from '../../components/ui'
import { formatPkt } from '../../format'
import type { UserDto } from '../../types'

export default function UsersPage() {
  const [items, setItems] = useState<UserDto[]>([])
  const [error, setError] = useState('')
  const [show, setShow] = useState(false)
  const [form, setForm] = useState({ username: '', password: '', fullName: '', email: '' })

  async function load() {
    try {
      setItems(await UsersApi.list())
    } catch (e) {
      setError(errorMessage(e))
    }
  }
  useEffect(() => { void load() }, [])

  async function create(e: FormEvent) {
    e.preventDefault()
    try {
      await UsersApi.create(form)
      setShow(false)
      setForm({ username: '', password: '', fullName: '', email: '' })
      await load()
    } catch (err) {
      setError(errorMessage(err))
    }
  }

  return (
    <div>
      <PageTitle title="Users" subtitle="Super Admin can create and manage Admin accounts." />
      {error ? <div className="mb-4"><Alert kind="err">{error}</Alert></div> : null}
      <div className="mb-4"><Button onClick={() => setShow(true)}>Create admin</Button></div>
      {show ? (
        <Card className="p-4 mb-4">
          <form onSubmit={create} className="grid md:grid-cols-2 gap-3">
            <Input placeholder="Username" required value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} />
            <Input placeholder="Temporary password" required value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
            <Input placeholder="Full name" value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} />
            <Input placeholder="Email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            <div className="md:col-span-2 flex gap-2">
              <Button type="submit">Save</Button>
              <Button variant="ghost" onClick={() => setShow(false)}>Cancel</Button>
            </div>
          </form>
        </Card>
      ) : null}
      <Card className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-slate-400 text-left">
            <tr>
              <th className="px-4 py-2 font-normal">Username</th>
              <th className="px-4 py-2 font-normal">Name</th>
              <th className="px-4 py-2 font-normal">Role</th>
              <th className="px-4 py-2 font-normal">Company</th>
              <th className="px-4 py-2 font-normal">Last login</th>
              <th className="px-4 py-2 font-normal">Status</th>
              <th className="px-4 py-2 font-normal"></th>
            </tr>
          </thead>
          <tbody>
            {items.map((u) => (
              <tr key={u.id} className="border-t border-[#1a3358]">
                <td className="px-4 py-2">{u.username}</td>
                <td className="px-4 py-2">{u.fullName}</td>
                <td className="px-4 py-2"><Badge>{u.role}</Badge></td>
                <td className="px-4 py-2">{u.companyName || '—'}</td>
                <td className="px-4 py-2">{formatPkt(u.lastLoginAt)}</td>
                <td className="px-4 py-2"><Badge tone={u.isActive ? 'green' : 'red'}>{u.isActive ? 'Active' : 'Inactive'}</Badge></td>
                <td className="px-4 py-2">
                  {u.role !== 'SuperAdmin' ? (
                    <button className="text-[#c9a227] text-xs" onClick={async () => {
                      await UsersApi.update(u.id, { isActive: !u.isActive })
                      await load()
                    }}>{u.isActive ? 'Deactivate' : 'Activate'}</button>
                  ) : null}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  )
}
