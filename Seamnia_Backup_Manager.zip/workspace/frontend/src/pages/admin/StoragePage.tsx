import { useEffect, useState } from 'react'
import { DashboardApi, errorMessage } from '../../api'
import { Alert, Badge, Card, PageTitle, Stat } from '../../components/ui'
import { formatBytes } from '../../format'

interface Row {
  id: number
  code: string
  companyName: string
  isActive: boolean
  backupCount: number
  storageUsedBytes: number
}

export default function StoragePage() {
  const [data, setData] = useState<{ totalStorageBytes: number; usedBytes: number; availableBytes: number; clients: Row[] } | null>(null)
  const [error, setError] = useState('')

  useEffect(() => {
    DashboardApi.storage().then(setData).catch((e) => setError(errorMessage(e)))
  }, [])

  if (error) return <Alert kind="err">{error}</Alert>
  if (!data) return <p className="text-slate-400">Loading storage…</p>
  const pct = data.totalStorageBytes ? Math.round((data.usedBytes / data.totalStorageBytes) * 100) : 0

  return (
    <div>
      <PageTitle title="Storage Management" subtitle="Physical .BAK files live under SeamniaBackupStorage, one folder per client." />
      <div className="grid md:grid-cols-3 gap-4">
        <Stat label="Allocated" value={formatBytes(data.totalStorageBytes)} />
        <Stat label="Used" value={formatBytes(data.usedBytes)} hint={`${pct}%`} />
        <Stat label="Available" value={formatBytes(data.availableBytes)} />
      </div>
      <div className="mt-4 h-3 rounded-full bg-[#122544] overflow-hidden">
        <div className="h-full bg-[#c9a227]" style={{ width: `${Math.min(100, pct)}%` }} />
      </div>
      <Card className="mt-6 overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-slate-400 text-left">
            <tr>
              <th className="px-4 py-2 font-normal">Folder</th>
              <th className="px-4 py-2 font-normal">Company</th>
              <th className="px-4 py-2 font-normal">Backups</th>
              <th className="px-4 py-2 font-normal">Used</th>
              <th className="px-4 py-2 font-normal">Status</th>
            </tr>
          </thead>
          <tbody>
            {data.clients.map((c) => (
              <tr key={c.id} className="border-t border-[#1a3358]">
                <td className="px-4 py-2 text-[#e4c56a]">{c.code}</td>
                <td className="px-4 py-2">{c.companyName}</td>
                <td className="px-4 py-2">{c.backupCount}</td>
                <td className="px-4 py-2">{formatBytes(c.storageUsedBytes)}</td>
                <td className="px-4 py-2"><Badge tone={c.isActive ? 'green' : 'red'}>{c.isActive ? 'Active' : 'Inactive'}</Badge></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  )
}
