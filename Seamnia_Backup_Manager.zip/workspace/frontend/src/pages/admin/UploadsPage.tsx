import { useEffect, useState } from 'react'
import { UploadsApi, errorMessage } from '../../api'
import { Alert, Badge, Button, Card, PageTitle, Select, statusTone } from '../../components/ui'
import { formatBytes, formatPkt } from '../../format'
import type { SessionDto } from '../../types'

export default function UploadsPage() {
  const [status, setStatus] = useState('')
  const [items, setItems] = useState<SessionDto[]>([])
  const [total, setTotal] = useState(0)
  const [error, setError] = useState('')

  async function load() {
    try {
      const res = await UploadsApi.monitoring({ status: status || undefined, page: 1, pageSize: 50 })
      setItems(res.items)
      setTotal(res.total)
    } catch (e) {
      setError(errorMessage(e))
    }
  }
  useEffect(() => { void load() }, [])

  return (
    <div>
      <PageTitle title="Upload Monitoring" subtitle="Track in-progress, completed and failed chunked uploads." />
      {error ? <Alert kind="err">{error}</Alert> : null}
      <div className="flex gap-3 mb-4">
        <Select value={status} onChange={(e) => setStatus(e.target.value)} className="max-w-xs">
          <option value="">All sessions</option>
          <option>Active</option>
          <option>Completed</option>
          <option>Failed</option>
          <option>Cancelled</option>
        </Select>
        <Button onClick={() => void load()}>Refresh</Button>
      </div>
      <Card className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-slate-400 text-left">
            <tr>
              <th className="px-4 py-2 font-normal">Client</th>
              <th className="px-4 py-2 font-normal">File</th>
              <th className="px-4 py-2 font-normal">Size</th>
              <th className="px-4 py-2 font-normal">Chunks</th>
              <th className="px-4 py-2 font-normal">Started</th>
              <th className="px-4 py-2 font-normal">Status</th>
              <th className="px-4 py-2 font-normal">Error</th>
            </tr>
          </thead>
          <tbody>
            {items.map((s) => (
              <tr key={s.id} className="border-t border-[#1a3358]">
                <td className="px-4 py-2">{s.clientName}</td>
                <td className="px-4 py-2">{s.originalFileName}</td>
                <td className="px-4 py-2">{formatBytes(s.fileSizeBytes)}</td>
                <td className="px-4 py-2">{s.receivedChunks}/{s.totalChunks}</td>
                <td className="px-4 py-2">{formatPkt(s.createdAt)}</td>
                <td className="px-4 py-2"><Badge tone={statusTone(s.status)}>{s.status}</Badge></td>
                <td className="px-4 py-2 text-red-300 text-xs">{s.errorMessage || '—'}</td>
              </tr>
            ))}
            {items.length === 0 ? <tr><td colSpan={7} className="px-4 py-6 text-slate-500">No upload sessions.</td></tr> : null}
          </tbody>
        </table>
      </Card>
      <p className="mt-3 text-xs text-slate-500">{total} sessions</p>
    </div>
  )
}
