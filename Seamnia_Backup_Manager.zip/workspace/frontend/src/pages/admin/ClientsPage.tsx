import { useEffect, useState, type FormEvent, type ReactNode } from 'react'
import { ClientsApi, errorMessage } from '../../api'
import { useAuth } from '../../AuthContext'
import { Alert, Badge, Button, Card, Input, PageTitle } from '../../components/ui'
import { formatBytes, formatPkt } from '../../format'
import type { ClientDto } from '../../types'

export default function ClientsPage() {
  const { user } = useAuth()
  const isSuper = user?.role === 'SuperAdmin'
  const [q, setQ] = useState('')
  const [items, setItems] = useState<ClientDto[]>([])
  const [total, setTotal] = useState(0)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [showCreate, setShowCreate] = useState(false)
  const [editing, setEditing] = useState<ClientDto | null>(null)
  const [creds, setCreds] = useState<{ username: string; password: string } | null>(null)

  async function load() {
    try {
      const res = await ClientsApi.list({ q, page: 1, pageSize: 100 })
      setItems(res.items)
      setTotal(res.total)
    } catch (e) {
      setError(errorMessage(e))
    }
  }

  useEffect(() => { void load() }, [])

  return (
    <div>
      <PageTitle title="Clients" subtitle={`${total} registered companies.`} />
      {error ? <Alert kind="err">{error}</Alert> : null}
      {notice ? <div className="mb-4"><Alert kind="ok">{notice}</Alert></div> : null}
      {creds ? (
        <div className="mb-4"><Alert kind="ok">Credentials for {creds.username}: {creds.password} — copy now, the password will not be shown again.</Alert></div>
      ) : null}
      <div className="flex gap-3 mb-4">
        <Input placeholder="Search company, code, contact or username" value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && void load()} />
        <Button variant="ghost" onClick={() => void load()}>Search</Button>
        {isSuper ? <Button onClick={() => setShowCreate(true)}>Create client</Button> : null}
      </div>
      <Card className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-slate-400 text-left">
            <tr>
              <th className="px-4 py-2 font-normal">Code</th>
              <th className="px-4 py-2 font-normal">Company</th>
              <th className="px-4 py-2 font-normal">Contact</th>
              <th className="px-4 py-2 font-normal">Username</th>
              <th className="px-4 py-2 font-normal">Backups</th>
              <th className="px-4 py-2 font-normal">Storage</th>
              <th className="px-4 py-2 font-normal">Last upload</th>
              <th className="px-4 py-2 font-normal">Status</th>
              <th className="px-4 py-2 font-normal"></th>
            </tr>
          </thead>
          <tbody>
            {items.map((c) => (
              <tr key={c.id} className="border-t border-[#1a3358]">
                <td className="px-4 py-2 text-[#e4c56a]">{c.code}</td>
                <td className="px-4 py-2">{c.companyName}</td>
                <td className="px-4 py-2 text-slate-300">{c.contactName}<div className="text-xs text-slate-500">{c.contactEmail}</div></td>
                <td className="px-4 py-2">{c.username}</td>
                <td className="px-4 py-2">{c.backupCount}</td>
                <td className="px-4 py-2">{formatBytes(c.storageUsedBytes)}</td>
                <td className="px-4 py-2">{formatPkt(c.lastUploadAt)}</td>
                <td className="px-4 py-2"><Badge tone={c.isActive ? 'green' : 'red'}>{c.isActive ? 'Active' : 'Inactive'}</Badge></td>
                <td className="px-4 py-2 text-right space-x-2 whitespace-nowrap">
                  {isSuper ? <button className="text-[#c9a227] text-xs" onClick={() => setEditing(c)}>Edit</button> : null}
                  {isSuper ? (
                    <button className="text-[#c9a227] text-xs" onClick={async () => {
                      try {
                        const r = await ClientsApi.resetPassword(c.id)
                        setCreds(r)
                        setNotice(`Password reset for ${r.username}.`)
                      } catch (e) { setError(errorMessage(e)) }
                    }}>Reset password</button>
                  ) : null}
                  <OverrideButton id={c.id} onDone={() => { setNotice('Quota override recorded in audit logs.'); void load() }} onErr={setError} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
      {showCreate ? <ClientForm onClose={() => setShowCreate(false)} onSaved={(c) => { setShowCreate(false); setCreds(c); void load() }} /> : null}
      {editing ? <EditClient client={editing} onClose={() => setEditing(null)} onSaved={() => { setEditing(null); void load() }} /> : null}
    </div>
  )
}

function OverrideButton({ id, onDone, onErr }: { id: number; onDone: () => void; onErr: (s: string) => void }) {
  return (
    <button
      className="text-[#c9a227] text-xs"
      onClick={async () => {
        const reason = window.prompt('Reason for extra weekly upload credit (required, logged in audit):')
        if (!reason) return
        try {
          await ClientsApi.overrideQuota(id, 1, reason)
          onDone()
        } catch (e) {
          onErr(errorMessage(e))
        }
      }}
    >
      Extra upload
    </button>
  )
}

function ClientForm({ onClose, onSaved }: { onClose: () => void; onSaved: (c: { username: string; password: string }) => void }) {
  const [form, setForm] = useState({ companyName: '', contactName: '', contactEmail: '', contactPhone: '', username: '', password: '' })
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  async function submit(e: FormEvent) {
    e.preventDefault()
    setBusy(true)
    setError('')
    try {
      const res = await ClientsApi.create(form)
      onSaved(res.credentials)
    } catch (err) {
      setError(errorMessage(err))
    } finally {
      setBusy(false)
    }
  }

  return (
    <Modal title="Create client" onClose={onClose}>
      <form onSubmit={submit} className="space-y-3">
        {error ? <Alert kind="err">{error}</Alert> : null}
        <Input placeholder="Company name" required value={form.companyName} onChange={(e) => setForm({ ...form, companyName: e.target.value })} />
        <Input placeholder="Contact name" value={form.contactName} onChange={(e) => setForm({ ...form, contactName: e.target.value })} />
        <Input placeholder="Contact email" value={form.contactEmail} onChange={(e) => setForm({ ...form, contactEmail: e.target.value })} />
        <Input placeholder="Contact phone" value={form.contactPhone} onChange={(e) => setForm({ ...form, contactPhone: e.target.value })} />
        <Input placeholder="Username (optional, auto-generated)" value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} />
        <Input placeholder="Password (optional, auto-generated)" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
        <div className="flex justify-end gap-2">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button type="submit" disabled={busy}>{busy ? 'Saving…' : 'Create'}</Button>
        </div>
      </form>
    </Modal>
  )
}

function EditClient({ client, onClose, onSaved }: { client: ClientDto; onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = useState({
    companyName: client.companyName,
    contactName: client.contactName,
    contactEmail: client.contactEmail,
    contactPhone: client.contactPhone,
    isActive: client.isActive,
  })
  const [error, setError] = useState('')

  async function submit(e: FormEvent) {
    e.preventDefault()
    try {
      await ClientsApi.update(client.id, form)
      onSaved()
    } catch (err) {
      setError(errorMessage(err))
    }
  }

  return (
    <Modal title={`Edit ${client.code}`} onClose={onClose}>
      <form onSubmit={submit} className="space-y-3">
        {error ? <Alert kind="err">{error}</Alert> : null}
        <Input value={form.companyName} onChange={(e) => setForm({ ...form, companyName: e.target.value })} />
        <Input value={form.contactName} onChange={(e) => setForm({ ...form, contactName: e.target.value })} />
        <Input value={form.contactEmail} onChange={(e) => setForm({ ...form, contactEmail: e.target.value })} />
        <Input value={form.contactPhone} onChange={(e) => setForm({ ...form, contactPhone: e.target.value })} />
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={form.isActive} onChange={(e) => setForm({ ...form, isActive: e.target.checked })} />
          Active
        </label>
        <div className="flex justify-end gap-2">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button type="submit">Save</Button>
        </div>
      </form>
    </Modal>
  )
}

function Modal({ title, children, onClose }: { title: string; children: ReactNode; onClose: () => void }) {
  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="w-full max-w-lg rounded-xl border border-[#1a3358] bg-[#0b1c36] p-5" onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg text-white">{title}</h3>
          <button className="text-slate-400" onClick={onClose}>Close</button>
        </div>
        {children}
      </div>
    </div>
  )
}
