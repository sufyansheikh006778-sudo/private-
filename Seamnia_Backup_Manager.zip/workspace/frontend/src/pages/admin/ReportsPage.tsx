import { useEffect, useState } from 'react'
import { ReportsApi, errorMessage } from '../../api'
import { Alert, Card, PageTitle, Stat } from '../../components/ui'
import { formatBytes } from '../../format'
import type { ReportDto } from '../../types'

export default function ReportsPage() {
  const [data, setData] = useState<ReportDto | null>(null)
  const [error, setError] = useState('')
  useEffect(() => {
    ReportsApi.get().then(setData).catch((e) => setError(errorMessage(e)))
  }, [])
  if (error) return <Alert kind="err">{error}</Alert>
  if (!data) return <p className="text-slate-400">Loading reports…</p>
  const max = Math.max(1, ...data.weeklyTrend.map((w) => w.count))

  return (
    <div>
      <PageTitle title="Reports" subtitle="Weekly upload trend and client storage ranking." />
      <div className="grid md:grid-cols-4 gap-4">
        <Stat label="Successful backups" value={String(data.successfulBackups)} />
        <Stat label="Failed sessions" value={String(data.failedBackups)} />
        <Stat label="Verified" value={String(data.verified)} />
        <Stat label="Verification failed" value={String(data.verificationFailed)} />
      </div>
      <Card className="mt-6 p-5">
        <h2 className="text-sm text-white mb-4">Weekly successful uploads (PKT weeks)</h2>
        <div className="flex items-end gap-3 h-40">
          {data.weeklyTrend.map((w) => (
            <div key={w.weekStart} className="flex-1 flex flex-col items-center gap-2">
              <div className="w-full bg-[#c9a227] rounded-t" style={{ height: `${(w.count / max) * 100}%`, minHeight: w.count ? 6 : 2 }} />
              <div className="text-[10px] text-slate-400">{w.weekStart}</div>
              <div className="text-xs text-white">{w.count}</div>
            </div>
          ))}
        </div>
      </Card>
      <Card className="mt-6 overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-slate-400 text-left">
            <tr>
              <th className="px-4 py-2 font-normal">Client</th>
              <th className="px-4 py-2 font-normal">Backups</th>
              <th className="px-4 py-2 font-normal">Storage</th>
            </tr>
          </thead>
          <tbody>
            {data.topClients.map((c) => (
              <tr key={c.code} className="border-t border-[#1a3358]">
                <td className="px-4 py-2">{c.companyName} <span className="text-slate-500">{c.code}</span></td>
                <td className="px-4 py-2">{c.backupCount}</td>
                <td className="px-4 py-2">{formatBytes(c.storageUsedBytes)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  )
}
