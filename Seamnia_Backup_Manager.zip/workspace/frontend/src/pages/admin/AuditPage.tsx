import { useEffect, useState } from 'react'
import { AuditApi, errorMessage } from '../../api'
import { Alert, Button, Card, Input, PageTitle } from '../../components/ui'
import { formatPkt } from '../../format'
import type { AuditLogDto } from '../../types'

export default function AuditPage() {
  const [q, setQ] = useState('')
  const [items, setItems] = useState<AuditLogDto[]>([])
  const [total, setTotal] = useState(0)
  const [error, setError] = useState('')

  async function load() {
    try {
      const res = await AuditApi.list({ q, page: 1, pageSize: 100 })
      setItems(res.items)
      setTotal(res.total)
    } catch (e) {
      setError(errorMessage(e))
    }
  }
  useEffect(() => { void load() }, [])

  return (
    <div>
      <PageTitle title="Audit Logs" subtitle="Every login, upload, download, deletion and quota override is recorded." />
      {error ? <Alert kind="err">{error}</Alert> : null}
      <div className="flex gap-3 mb-4">
        <Input placeholder="Search user, action or details" value={q} onChange={(e) => setQ(e.target.value)} />
        <Button onClick={() => void load()}>Search</Button>
      </div>
      <Card className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-slate-400 text-left">
            <tr>
              <th className="px-4 py-2 font-normal">When</th>
              <th className="px-4 py-2 font-normal">User</th>
              <th className="px-4 py-2 font-normal">Action</th>
              <th className="px-4 py-2 font-normal">Entity</th>
              <th className="px-4 py-2 font-normal">Details</th>
              <th className="px-4 py-2 font-normal">IP</th>
            </tr>
          </thead>
          <tbody>
            {items.map((a) => (
              <tr key={a.id} className="border-t border-[#1a3358]">
                <td className="px-4 py-2 whitespace-nowrap">{formatPkt(a.createdAt)}</td>
                <td className="px-4 py-2">{a.username}<div className="text-xs text-slate-500">{a.role}</div></td>
                <td className="px-4 py-2 text-[#e4c56a]">{a.action}</td>
                <td className="px-4 py-2">{a.entityType} {a.entityId}</td>
                <td className="px-4 py-2 text-slate-300">{a.details}</td>
                <td className="px-4 py-2 text-slate-500">{a.ipAddress}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
      <p className="mt-3 text-xs text-slate-500">{total} events</p>
    </div>
  )
}
