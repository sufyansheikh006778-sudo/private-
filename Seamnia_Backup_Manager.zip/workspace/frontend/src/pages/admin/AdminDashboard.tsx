import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { DashboardApi, errorMessage } from '../../api'
import { Badge, Card, PageTitle, Stat, statusTone, Alert } from '../../components/ui'
import { formatBytes, formatPkt } from '../../format'
import type { DashboardStats } from '../../types'

export default function AdminDashboard() {
  const [data, setData] = useState<DashboardStats | null>(null)
  const [error, setError] = useState('')

  useEffect(() => {
    DashboardApi.admin().then(setData).catch((e) => setError(errorMessage(e)))
  }, [])

  if (error) return <Alert kind="err">{error}</Alert>
  if (!data) return <p className="text-slate-400">Loading dashboard…</p>

  return (
    <div>
      <PageTitle title="Operations Dashboard" subtitle="Live overview of clients, weekly uploads and storage." />
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Stat label="Total Clients" value={String(data.totalClients)} />
        <Stat label="Active Clients" value={String(data.activeClients)} />
        <Stat label="Total Backups" value={String(data.totalBackups)} />
        <Stat label="Weekly Uploads" value={String(data.weeklyUploads)} hint="Monday–Sunday PKT" />
        <Stat label="Storage Used" value={formatBytes(data.storageUsedBytes)} />
        <Stat label="Available Storage" value={formatBytes(data.availableStorageBytes)} />
        <Stat label="Pending" value={String(data.pendingBackups)} hint="Active uploads + pending verification" />
        <Stat label="Failed Uploads" value={String(data.failedUploads)} />
      </div>
      <Card className="mt-6 overflow-hidden">
        <div className="px-5 py-3 border-b border-[#1a3358] flex justify-between items-center">
          <h2 className="text-sm font-medium text-white">Latest Uploads</h2>
          <Link to="/admin/backups" className="text-xs text-[#c9a227]">View all</Link>
        </div>
        <table className="w-full text-sm">
          <thead className="text-slate-400 text-left">
            <tr>
              <th className="px-5 py-2 font-normal">Client</th>
              <th className="px-5 py-2 font-normal">File</th>
              <th className="px-5 py-2 font-normal">Size</th>
              <th className="px-5 py-2 font-normal">Uploaded</th>
              <th className="px-5 py-2 font-normal">Status</th>
              <th className="px-5 py-2 font-normal">Verification</th>
            </tr>
          </thead>
          <tbody>
            {data.latestUploads.length === 0 ? (
              <tr><td colSpan={6} className="px-5 py-6 text-slate-500">No backups yet.</td></tr>
            ) : data.latestUploads.map((b) => (
              <tr key={b.id} className="border-t border-[#1a3358]">
                <td className="px-5 py-2">{b.clientName}</td>
                <td className="px-5 py-2 text-slate-300">{b.originalFileName}</td>
                <td className="px-5 py-2">{formatBytes(b.fileSizeBytes)}</td>
                <td className="px-5 py-2">{formatPkt(b.completedAt || b.createdAt)}</td>
                <td className="px-5 py-2"><Badge tone={statusTone(b.uploadStatus)}>{b.uploadStatus}</Badge></td>
                <td className="px-5 py-2"><Badge tone={statusTone(b.verificationStatus)}>{b.verificationStatus}</Badge></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  )
}
