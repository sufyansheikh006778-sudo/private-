import { useState, type FormEvent } from 'react'
import { useNavigate } from 'react-router-dom'
import { errorMessage } from '../api'
import { useAuth } from '../AuthContext'
import { Alert, Button, Input } from '../components/ui'

export default function Login() {
  const { login } = useAuth()
  const navigate = useNavigate()
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  async function onSubmit(e: FormEvent) {
    e.preventDefault()
    setError('')
    setBusy(true)
    try {
      const user = await login(username, password)
      navigate(user.role === 'Client' ? '/client' : '/admin')
    } catch (err) {
      setError(errorMessage(err, 'Unable to sign in.'))
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#050d1a] flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="text-xs tracking-[0.3em] text-[#c9a227] uppercase">Seamnia Software House</div>
          <h1 className="mt-2 text-3xl font-semibold text-white">Backup Manager</h1>
          <p className="mt-2 text-sm text-slate-400">Secure weekly SQL Server backup portal</p>
        </div>
        <form onSubmit={onSubmit} className="rounded-xl border border-[#1a3358] bg-[#0b1c36] p-6 space-y-4">
          {error ? <Alert kind="err">{error}</Alert> : null}
          <label className="block text-sm text-slate-300">
            Username
            <Input className="mt-1" value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="username" required />
          </label>
          <label className="block text-sm text-slate-300">
            Password
            <Input className="mt-1" type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" required />
          </label>
          <Button type="submit" disabled={busy} className="w-full">
            {busy ? 'Signing in…' : 'Sign in'}
          </Button>
          <p className="text-xs text-slate-500 text-center">Access is restricted to Seamnia clients and administrators.</p>
        </form>
      </div>
    </div>
  )
}
